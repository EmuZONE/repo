#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui
from BeautifulSoup import BeautifulSoup as BS
def HTML_READ(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
def NAME_REPLACE(s):
    return s.replace('&bdquo;','Ä').replace('&circ;','ä').replace('&oelig;','Ü').replace('&ndash;','Ö').replace('&Yuml;','ß').replace('&euro;&ldquo;','-')
def addDir(name,id,url,mode,iconimage):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&id="+urllib.quote_plus(id)
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
def SEARCH(url):
    kb = xbmc.Keyboard('','Search Dokuhouse', False)
    kb.doModal()
    search = kb.getText()
    search=search.decode('utf-8', 'ignore').encode('iso-8859-1','ignore')
    search=urllib.quote(search)
    url_search = 'http://www.dokuhouse.de/?s='+search
    VIDEOIDX(url_search)
def CATEGORIES(url):
    match3=re.compile('<li id="(.*?)" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item\-.*?"><a href="(.*?)">(.*?)</a>\n<ul class="sub-menu">').findall(HTML_READ(url))
    addDir('Search articles','','http://www.dokuhouse.de/',4,'')
    addDir('Latest articles','','http://www.dokuhouse.de/',2,'')	
    for id,url,name in match3:
        addDir(name,id,url,1,'')
    xbmc.executebuiltin("Container.SetViewMode(300)")    
def INDEX(url,name,id):
    soup = BS(HTML_READ(url))
    for li in soup.find("li",{"id": id},smartQuotesTo=None).find('ul',{"class": "sub-menu"},smartQuotesTo=None):
        match=re.compile('<li id="menu-item-.*?" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-.*?"><a href="(.*?)">(.*?)</a></li>').findall(str(li))
        for url,name in match:
            addDir(NAME_REPLACE(name.decode('utf-8', 'ignore').encode('iso-8859-1', 'ignore')),'',url,2,'')
    xbmc.executebuiltin("Container.SetViewMode(300)")
def VIDEOIDX(url1):
    soup = BS(HTML_READ(url1))
    for div in soup.find('div', {"class": "main-loop-inner"}).findAll('div',{"class": "panel-wrapper"}):
        try:
            url = div.find('a')['href']
            img = div.find('img')['src']
            name = div.find('img')['title']
            addDir(NAME_REPLACE(name.encode('iso-8859-1','ignore')),'',url,3,img)
        except:
            pass
    try:
        url=url1
        seite_now =''
        next_seite =''
        last_seite =''
        last_seite_of_seite =''
        if 'page/' in url1:
            url = re.search('(.*?)page/.*?',url1).group(1)
        for seite in soup.find('div', {"class": "span12 pagination-inner-mobile"}).find('div',{"class": "sort-buttons"}):
            if 'active' in str(seite) and not 'inactive' in str(seite):
                seite_now = str(seite['data-paginated'])
                next_seite = str(int(seite_now) + 1)
            if 'inactive' in str(seite):
                last_seite_of_seite = str(seite['data-paginated'])
            if 'inactive last' in str(seite):
                last_seite = str(seite['data-paginated'])
        if not last_seite == '':
            if not int(next_seite) > int(last_seite):
                addDir('[COLOR red]Seite ([/COLOR] ' + '[COLOR lime]' + seite_now + '[/COLOR]' + ' [COLOR red]) von ([/COLOR] '+ '[COLOR lime]' + last_seite + '[/COLOR]' + ' [COLOR red] ) >>>[/COLOR]','',url+'page/'+ next_seite,2,'')
                addDir('[COLOR red]Seite ([/COLOR] ' + '[COLOR lime]' + seite_now + '[/COLOR]' + ' [COLOR red]) von ([/COLOR] '+ '[COLOR lime]' + last_seite + '[/COLOR]' + ' [COLOR red] ) Nummer ?[/COLOR]','',url+'page/',5,'')
        else:
            if not int(next_seite) > int(last_seite_of_seite):
                addDir('[COLOR red]Seite ([/COLOR] ' + '[COLOR lime]' + seite_now + '[/COLOR]' + ' [COLOR red]) von ([/COLOR] '+ '[COLOR lime]' + last_seite_of_seite + '[/COLOR]' + ' [COLOR red] ) >>>[/COLOR]','',url+'page/'+ next_seite,2,'')
                addDir('[COLOR red]Seite ([/COLOR] ' + '[COLOR lime]' + seite_now + '[/COLOR]' + ' [COLOR red]) von ([/COLOR] '+ '[COLOR lime]' + last_seite_of_seite + '[/COLOR]' + ' [COLOR red] ) Nummer ?[/COLOR]','',url+'page/',5,'')
    except :
        pass
    xbmc.executebuiltin("Container.SetViewMode(300)")
def PLAY(title,url,image):
    stream_url = re.search('<iframe width=".*?" height=".*?" src=".*?//.*?/.*?/(.*?)"',HTML_READ(url),re.I).group(1)
    if stream_url:
        player = xbmc.Player()
        xlistitem = xbmcgui.ListItem(title,iconImage=image,thumbnailImage=image)
        xlistitem.setInfo( "video",{ "Title":title} )
        player.play('plugin://plugin.video.youtube/?action=play_video&videoid=' + stream_url,xlistitem)
    sys.exit(0)
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]                      
        return param          
params=get_params()
try:
    url=None
    url=urllib.unquote_plus(params["url"])
except:
    pass
try:
    name=None
    name=urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode=None
    mode=int(params["mode"])
except:
    pass
try:
    id=None
    id=urllib.unquote_plus(params["id"])
except:
    pass
try:
    iconimage=None
    iconimage=urllib.unquote_plus(params["thumbnailImage"])
except:
    pass
if mode==None or url==None or len(url)<1:
    CATEGORIES('http://www.dokuhouse.de/dokus/')    
elif mode==1:
    INDEX(url,name,id)    
elif mode==2:
    VIDEOIDX(url)     
elif mode==3:
    PLAY(name,url,iconimage)      
elif mode==4:
    SEARCH(url)
elif mode==5:
    max_nr = str(xbmc.getInfoLabel('ListItem.Title').replace('[COLOR red]','').replace('[COLOR lime]','').replace('[/COLOR]','').split('(')[2].split(')')[0]).strip()
    keyboard_nr = str(xbmcgui.Dialog().numeric(0, 'Seiten Nr. ? Max Nr. ' + max_nr , ''));
    if not keyboard_nr =='':
        if not max_nr == '':
            if not int(keyboard_nr) > int(max_nr):
                VIDEOIDX(url + keyboard_nr)
            else:
                sys.exit(0)
        else:
            VIDEOIDX(url + keyboard_nr)
    else:
        sys.exit(0)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
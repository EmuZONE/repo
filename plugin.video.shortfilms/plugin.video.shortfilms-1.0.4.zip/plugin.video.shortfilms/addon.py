import xbmcgui,xbmcplugin,xbmcaddon,os,sys,base64

addon = xbmcaddon.Addon()
plugin_handle = int(sys.argv[1])
xbmcplugin.setContent(handle=int(sys.argv[1]), content='movies')
	
def add_video_item(url, infolabels, img=''):
    listitem = xbmcgui.ListItem(infolabels['title'], iconImage=img, thumbnailImage=img)
    listitem.setInfo('video', infolabels)
    listitem.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem)
	
try:
    f = open(os.path.join(addon.getAddonInfo('path'), "data"), 'r')
    text = f.read()
    f.close()
except:
    exit(1)

for line in text.split('\n'):
        line = base64.b64decode(line)
        if '*' in line:
            
            try:
                url_name_icon = line.split('*')
                if url_name_icon[0].startswith('http:'): 
                    add_video_item(url_name_icon[0],{'title':url_name_icon[1]}, os.path.join(addon.getAddonInfo('path'), "icons", url_name_icon[2]))
                else:
                    play_url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % url_name_icon[0]
                    add_video_item(play_url,{'title':url_name_icon[1]}, os.path.join(addon.getAddonInfo('path'), "icons", url_name_icon[2]))
            except:
                exit(1)
xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=True)			
xbmc.executebuiltin('Container.SetViewMode(100)')


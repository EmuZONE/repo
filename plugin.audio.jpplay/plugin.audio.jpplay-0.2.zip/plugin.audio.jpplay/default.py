import menu, util, urllib
import xbmcplugin, xbmcaddon, xbmcgui


sysarg=str(sys.argv[1])
ADDON_ID='plugin.audio.jpplay'
addon = xbmcaddon.Addon(id=ADDON_ID)
parameters=util.parseParameters()
try:
    mode=int(parameters["mode"])
except:
    mode=None
    
if mode==1: # trending menu
    util.addMenuItems(menu.liveMenu)
elif mode==2: # load a page and find the albums
    util.loadAlbums(parameters)
elif mode==3: # load a album
    util.loadAlbum(parameters)
elif mode==4: # search artists
    util.searchArtists(parameters)
elif mode==5: # search by letter of the alphabet
    util.artistByLetter(parameters)
elif mode==6: # top 10 listened to albums
    util.topAlbums(parameters)
elif mode==7: # search songs
    util.searchSongs(parameters)
elif mode==8: #search albums
    util.searchAlbums(parameters)
elif mode==100: # play media
    util.playMedia(parameters['name'], parameters['icon'], parameters['url'], parameters['extras'].encode('utf-8'), parameters['fanart'])
else:
    if parameters:
        util.addMenuItems(menu.menu[parameters['url']])
    else:
        util.addMenuItems(menu.menu['mainMenu'])
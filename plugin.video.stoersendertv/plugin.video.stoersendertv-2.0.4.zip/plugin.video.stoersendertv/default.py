#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc

xbmc.executebuiltin('Container.Update(plugin://plugin.video.youtube/?path=/root/explore/categories&feed=uploads&channel=stoersendertv)')

class PageletFactory(object):

    def __init__(self, log):
        self.log = log
                 
    def createPagelet(self, context, pageletId, params):
        pass

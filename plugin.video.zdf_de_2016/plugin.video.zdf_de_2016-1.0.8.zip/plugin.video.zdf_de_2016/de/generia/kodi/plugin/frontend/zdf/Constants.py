
class Constants(object):
    baseUrl = 'https://www.zdf.de'
    apiBaseUrl = 'https://api.zdf.de'
    showsAzUrl = '/sendungen-a-z'

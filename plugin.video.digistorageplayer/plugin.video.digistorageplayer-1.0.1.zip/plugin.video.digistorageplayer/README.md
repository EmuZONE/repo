Digi Storage Player for Kodi

Tested for Jarvis and Krypton

Version 1.0

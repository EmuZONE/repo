
# Feedreader
## an rss sreensaver for KODI/XBMC

Feedreader will shows you the news and images from multiple rss feeds of your choice.

* [Author website](http://www.glaciology.net)
* [Forum url](http://forum.kodi.tv/showthread.php?tid=208160)
* [Kodi addon page](http://addons.kodi.tv/show/script.screensaver.feedreader/)

# Screenshots

![Screenshot screensaver](http://i.imgur.com/PTeQIiD.png)
![Screenshot settings](http://i.imgur.com/DQnBt5A.png)

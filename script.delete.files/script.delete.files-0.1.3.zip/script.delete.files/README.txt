Delete Files

About: 
This Addon deletes old files based on a pattern that you can choose

Using This Addon: 
Simply run "RunAddon(script.delete.files)" and you're good to go


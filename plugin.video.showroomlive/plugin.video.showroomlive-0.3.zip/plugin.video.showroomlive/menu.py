import sys, urllib, os
import xbmc, xbmcplugin, xbmcgui, xbmcaddon

sysarg=str(sys.argv[1])
ADDON_ID='plugin.video.showroomlive'
addon=xbmcaddon.Addon(id=ADDON_ID)
home=xbmc.translatePath(addon.getAddonInfo('path').decode('utf-8'))

# the main menu structure
showroomMenu=[
    {
        "title":"Live", 
        "url":"https://showroom-live.com/onlive/", 
        "mode":1, 
        "poster":"none",
        "icon":"default.jpg", 
        "fanart":os.path.join(home, '', 'fanart.jpg'),
        "type":"", 
        "plot":"",
        "isFolder":True,
    }
]
#https://www.showroom-live.com/room/get_streaming_url?room_id=138135
#https://www.showroom-live.com/api/live/upcoming
liveMenu=[
    {
        "title":"Popularity", 
        "url":"https://www.showroom-live.com/api/live/onlives", 
        "mode":2, 
        "poster":"none",
        "icon":"default.jpg", 
        "fanart":os.path.join(home, '', 'fanart.jpg'),
        "type":"", 
        "plot":"",
        "isFolder":True,
    }, {
        "title":"Idol", 
        "url":"https://www.showroom-live.com/api/live/onlives", 
        "mode":2, 
        "poster":"none",
        "icon":"default.jpg", 
        "fanart":os.path.join(home, '', 'fanart.jpg'),
        "type":"", 
        "plot":"",
        "isFolder":True,
    }, {
        "title":"Talent Model", 
        "url":"https://www.showroom-live.com/api/live/onlives", 
        "mode":2, 
        "poster":"none",
        "icon":"default.jpg", 
        "fanart":os.path.join(home, '', 'fanart.jpg'),
        "type":"", 
        "plot":"",
        "isFolder":True,
    }, {
        "title":"Music", 
        "url":"https://www.showroom-live.com/api/live/onlives", 
        "mode":2, 
        "poster":"none",
        "icon":"default.jpg", 
        "fanart":os.path.join(home, '', 'fanart.jpg'),
        "type":"", 
        "plot":"",
        "isFolder":True,
    }, {
        "title":"Voice Actors & Anime", 
        "url":"https://www.showroom-live.com/api/live/onlives", 
        "mode":2, 
        "poster":"none",
        "icon":"default.jpg", 
        "fanart":os.path.join(home, '', 'fanart.jpg'),
        "type":"", 
        "plot":"",
        "isFolder":True,
    }, {
        "title":"Comedians/Talk Show", 
        "url":"https://www.showroom-live.com/api/live/onlives", 
        "mode":2, 
        "poster":"none",
        "icon":"default.jpg", 
        "fanart":os.path.join(home, '', 'fanart.jpg'),
        "type":"", 
        "plot":"",
        "isFolder":True,
    }, {
        "title":"Sports", 
        "url":"https://www.showroom-live.com/api/live/onlives", 
        "mode":2, 
        "poster":"none",
        "icon":"default.jpg", 
        "fanart":os.path.join(home, '', 'fanart.jpg'),
        "type":"", 
        "plot":"",
        "isFolder":True,
    }, {
        "title":"Non-Professionals", 
        "url":"https://www.showroom-live.com/api/live/onlives", 
        "mode":2, 
        "poster":"none",
        "icon":"default.jpg", 
        "fanart":os.path.join(home, '', 'fanart.jpg'),
        "type":"", 
        "plot":"",
        "isFolder":True,
    }
]
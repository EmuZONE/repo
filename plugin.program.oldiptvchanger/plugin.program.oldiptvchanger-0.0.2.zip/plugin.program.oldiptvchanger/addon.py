#!/usr/bin/python
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,os,sys,urllib,urllib2,shutil,time

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo("path").decode('utf-8')

def DeleteFile(deletefile):
    if os.path.isfile(os.path.join(addon_path,deletefile)):
        try:
            os.remove(os.path.join(addon_path,deletefile))
        except:
            pass
			
def DownloadFile(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("SIMPLE CLIENT IPTV CHANGER","Download File ",os.path.basename(url))
	
    try:
        urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))
    except Exception, e:
        dp.close()
        xbmcgui.Dialog().ok("DOWNLOAD ERROR !", str(e))
        sys.exit()
		
def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled(): 
        dp.close()	
        sys.exit()
	
try:
    f = open(os.path.join(addon_path, "data.txt").decode('utf-8'), 'r')
    text = f.read().decode('utf-8')
    f.close()
except Exception, e:
    xbmcgui.Dialog().ok("Data Error !", str(e))
    sys.exit()

anzeige_array=[]

m3u_pathtype_array=[]
m3u_path_array=[]
m3u_download_array=[]
epg_pathtype_array=[]
epg_path_array=[]
epg_download_array=[]
logos_pathtype_array=[]
logos_path_array=[]
logos_download_array=[]

logo_from_epg_array=[]

anzeie_file_browser=["URL ZUR DATEN TXT EINGEBEN !","PFAD ZUR DATEN TXT AUSWAEHLEN !"]

if not text == "":
    try:
   
        for line in text.split('\n'):

            if int(line.count("*")) == 10:
		
                anzeige,m3u_pathtype,m3u_path,m3u_download,epg_pathtype,epg_path,epg_download,logos_pathtype,logos_path,logos_download,logo_from_epg = line.split('*')

                anzeige_array.append(anzeige)
		
                m3u_pathtype_array.append(m3u_pathtype)
                m3u_path_array.append(m3u_path)
                m3u_download_array.append(m3u_download)

                epg_pathtype_array.append(epg_pathtype)
                epg_path_array.append(epg_path)
                epg_download_array.append(epg_download)

                logos_pathtype_array.append(logos_pathtype)
                logos_path_array.append(logos_path)
                logos_download_array.append(logos_download)
				
                logo_from_epg_array.append(logo_from_epg)
	
    except Exception, e:
        xbmcgui.Dialog().ok("ARRAYS DATEN ERROR !", str(e))

call =  xbmcgui.Dialog().select("IPTV AUSWAHL !",  anzeige_array)

if call == -1:
    sys.exit()

if ((int(m3u_pathtype_array[call]) == 1) and (int(m3u_download_array[call]) == 1)):
    xbmcgui.Dialog().ok("Eingabeformat Error !","Wird die M3U gedownloadet muss der Pathtype ( 0 ) sein !")
    sys.exit()
	
if ((int(epg_pathtype_array[call]) == 1) and (int(epg_download_array[call]) == 1)):
    xbmcgui.Dialog().ok("Eingabeformat Error !","Wird das EPG gedownloadet muss der Pathtype ( 0 ) sein !")
    sys.exit()
	
if ((int(logos_pathtype_array[call]) == 1) and (int(logos_download_array[call]) == 1)):
    xbmcgui.Dialog().ok("Eingabeformat Error !","Werden die Logos gedownloadet muss der Pathtype ( 0 ) sein !")
    sys.exit()
	
xbmc.executebuiltin('PlayerControl(Stop)')
if ((int(m3u_pathtype_array[call]) == 1) and (int(m3u_download_array[call]) == 1)):
    xbmcgui.Dialog().ok("EINGABEFORMAT ERROR !","Wird die M3U gedownloadet muss der Pathtype ( 0 ) sein !")
    sys.exit()
	
if ((int(epg_pathtype_array[call]) == 1) and (int(epg_download_array[call]) == 1)):
    xbmcgui.Dialog().ok("EINGABEFORMAT ERROR !","Wird das EPG gedownloadet muss der Pathtype ( 0 ) sein !")
    sys.exit()
	
if ((int(logos_pathtype_array[call]) == 1) and (int(logos_download_array[call]) == 1)):
    xbmcgui.Dialog().ok("EINGABEFORMAT ERROR !","Werden die Logos gedownloadet muss der Pathtype ( 0 ) sein !")
    sys.exit()
	
xbmc.executebuiltin('PlayerControl(Stop)')
time.sleep(1)

if ((int(m3u_pathtype_array[call]) == 0) or (int(m3u_pathtype_array[call]) == 1) and (int(m3u_download_array[call]) == 0)):
    DeleteFile("m3u")
    m3u = str(m3u_path_array[call])	
if ((int(m3u_pathtype_array[call]) == 0) and (int(m3u_download_array[call]) == 1)):
    DeleteFile("m3u")
    DownloadFile(str(m3u_path_array[call]),os.path.join(addon_path,"m3u"))
    m3u =os.path.join(addon_path,"m3u")

if ((int(epg_pathtype_array[call]) == 0) or (int(epg_pathtype_array[call]) == 1) and (int(epg_download_array[call]) == 0)):
    DeleteFile("epg")
    epg = str(epg_path_array[call])	
if ((int(epg_pathtype_array[call]) == 0) and (int(epg_download_array[call]) == 1)):
    DeleteFile("epg")
    DownloadFile(str(epg_path_array[call]),os.path.join(addon_path,"epg"))
    epg =os.path.join(addon_path,"epg")
	
if ((int(logos_pathtype_array[call]) == 0) or (int(logos_pathtype_array[call]) == 1) and (int(logos_download_array[call]) == 0)):
    DeleteFile("logos")
    logos = str(logos_path_array[call])	
if ((int(logos_pathtype_array[call]) == 0) and (int(logos_download_array[call]) == 1)):
    DeleteFile("logos")
    DownloadFile(str(logos_path_array[call]),os.path.join(addon_path,"logos"))
    logos =os.path.join(addon_path,"logos")

addon.setSetting("sep1", "")
addon.setSetting("startNum", "1")
addon.setSetting("m3uCache", "true")		
addon.setSetting("epgCache", "true")
addon.setSetting("epgTSOverride", "false")
addon.setSetting("epgTimeShift", "0.000000")

if int(m3u_pathtype_array[call]) == 0:
    addon.setSetting("m3uUrl", "")
    addon.setSetting("m3uPath", m3u)
    addon.setSetting("m3uPathType", "0")
elif int(m3u_pathtype_array[call]) == 1:
    addon.setSetting("m3uUrl", m3u)
    addon.setSetting("m3uPath", "")
    addon.setSetting("m3uPathType", "1")
	
if int(epg_pathtype_array[call]) == 0:
    addon.setSetting("epgUrl", "")
    addon.setSetting("epgPath", epg)
    addon.setSetting("epgPathType", "0")
elif int(epg_pathtype_array[call]) == 1:
    addon.setSetting("epgUrl", epg)
    addon.setSetting("epgPath", "")
    addon.setSetting("epgPathType", "1")
	
if int(logos_pathtype_array[call]) == 0:
    addon.setSetting("logoBaseUrl", "")
    addon.setSetting("logoPath", logos)
    addon.setSetting("logoPathType", "0")
elif int(logos_pathtype_array[call]) == 1:
    addon.setSetting("logoBaseUrl", logos)
    addon.setSetting("logoPath", "")
    addon.setSetting("logoPathType", "1")

if ((int(logo_from_epg_array[call]) == 0) or (int(logo_from_epg_array[call]) == 1) or (int(logo_from_epg_array[call]) == 2 )):
    addon.setSetting("logoFromEpg", logo_from_epg_array[call])
else:
    xbmcgui.Dialog().ok("EINGABEFORMAT ERROR !","Senderlogos von XMLTV muss 0 oder 1 oder 2 sein !")
    sys.exit()

move_path1  = os.path.join(xbmc.translatePath("special://home"),"userdata","addon_data","plugin.program.oldiptvchanger")
move_path2  = os.path.join(xbmc.translatePath("special://home"),"userdata","addon_data","pvr.iptvsimple")

try:
    if os.path.exists(move_path2):
        shutil.rmtree(move_path2, ignore_errors=True)
		
    os.makedirs(move_path2)
    shutil.move(os.path.join(move_path1, "settings.xml"), os.path.join(move_path2, "settings.xml"))	
	
except Exception, e:
    xbmcgui.Dialog().ok("SETINGS MOVE ERROR !", str(e))
    sys.exit()

xbmc.executebuiltin("StopPVRManager")
time.sleep(1)	
xbmc.executebuiltin("StartPVRManager")
	  
xbmcgui.Dialog().ok("SIMPLE CLIENT IPTV CHANGER : INFO !","Die IPTV Adressen wurden gesetzt !")
#Created by Loki1979 | Andre Albus - 10.02.2016 - 00:10
define([
    './playlist'
], function () {});
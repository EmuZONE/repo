define([
    './plugin',
    './youtube',
    './playlist',
    './tvStudio',
    './rss'
], function () {});
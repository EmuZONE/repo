define([
    './moviesList',
    './moviesDetails.min'
], function () {});
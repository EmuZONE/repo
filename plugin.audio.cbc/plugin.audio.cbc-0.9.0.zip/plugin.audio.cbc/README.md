# plugin.audio.cbc
Addon to provide CBC radio audio streams in Kodi media center.

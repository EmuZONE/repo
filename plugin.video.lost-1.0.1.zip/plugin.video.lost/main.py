# -*- coding: utf-8 -*-
# Module: default
# Author: Roman V. M.
# Created on: 28.11.2014
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
from urllib import urlencode
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

# Free sample videos are provided by www.vidsplay.com
# Here we use a fixed set of properties simply for demonstrating purposes
# In a "real life" plugin you will need to get info and links to video files/streams
# from some web-site or online service.
VIDEOS = {'Staffel 1': [{'name': '01. Gestrandet (1)',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/Lost_Season_1_Score_Cover.jpg',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e01.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '02. Gestrandet (2)',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e02.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '03. Tabula Rasa',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e03.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '04. Wildschweinjagd',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e04.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '05. Das weisse Kaninchen',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e05.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '06. Die Höhle',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e06.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '07. Der Nachtfalter',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e07.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '08. Der Betrüger',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e08.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '09. Einzelhaft',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e09.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '10. Volkszaehlung',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e10.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '11. Faehrtensucher',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e11.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '12. Der silberne Koffer',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e12.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '13. Gefühl und Verstand',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e13.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '14. Eisbaer',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e14.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '15. Heimkehr',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e15.avi.mp4',
                      'genre': 'Crime'},
                      {'name': '16. Outlaws',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e16.avi.mp4',
                      'genre': 'Crime'},
                      {'name': '17. � In Translation',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e17.avi.mp4',
                      'genre': 'Crime'},
                      {'name': '18. Verfluchte Zahlen',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e18.avi.mp4',
                      'genre': 'Crime'},
                      {'name': '19. Deus Ex Machina',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e19.avi.mp4',
                      'genre': 'Crime'},
                      {'name': '20. Schade nicht',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e20.avi.mp4',
                      'genre': 'Crime'},
                      {'name': '21. Ein hoeheres Ziel',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e21.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '22. Rastlos',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e22.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '23. Exodus (1)',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e23.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '24. Exodus (2)',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e24.avi.mp4',
                      'genre': 'Crime'},
                     {'name': '25. Exodus (3)',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S01/itg-lost-s01e25.avi.mp4',
                      'genre': 'Crime'}
                    ],
                      
                      'Staffel 2': [{'name': '01. Glaube und Wissenschaft',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/Lost002.jpg',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e01.mp4',
                      'genre': 'Crime'},
                     {'name': '02. Treibholz',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e02.mp4',
                      'genre': 'Crime'},
                     {'name': '03. Orientierung',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e03.mp4',
                      'genre': 'Crime'},
                     {'name': '04. Alle hassen Hugo',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e04.mp4',
                      'genre': 'Crime'},
                     {'name': '05. Gefunden',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e05.mp4',
                      'genre': 'Crime'},
                     {'name': '06. Verlassen',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e06.mp4',
                      'genre': 'Crime'},
                     {'name': '07. Die anderen 48 Tage',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e07.mp4',
                      'genre': 'Crime'},
                     {'name': '08. Kollision',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e08.mp4',
                      'genre': 'Crime'},
                     {'name': '09. Was Kate getan hat',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e09.mp4',
                      'genre': 'Crime'},
                     {'name': '10. Psalm 23',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e10.mp4',
                      'genre': 'Crime'},
                     {'name': '11. Jagdgesellschaft',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e11.mp4',
                      'genre': 'Crime'},
                     {'name': '12. Feuer und Wasser',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e12.mp4',
                      'genre': 'Crime'},
                     {'name': '13. Langer Atem',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e13.mp4',
                      'genre': 'Crime'},
                     {'name': '14. Einer von Ihnen',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e14.mp4',
                      'genre': 'Crime'},
                     {'name': '15. Mutterschutz',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e15.mp4',
                      'genre': 'Crime'},
                      {'name': '16. Die ganze Wahrheit',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e16.mp4',
                      'genre': 'Crime'},
                      {'name': '17. Verriegelt',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e17.mp4',
                      'genre': 'Crime'},
                      {'name': '18. Dave',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e18.mp4',
                      'genre': 'Crime'},
                      {'name': '19. S.O.S.',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e19.mp4',
                      'genre': 'Crime'},
                      {'name': '20. Zwei für unterwegs',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e20.mp4',
                      'genre': 'Crime'},
                      {'name': '21. Fragezeichen',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e21.mp4',
                      'genre': 'Crime'},
                     {'name': '22. Drei Minuten',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e22.mp4',
                      'genre': 'Crime'},
                     {'name': '23. Zusammen leben - Alleine sterben (1)',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e23.mp4',
                      'genre': 'Crime'},
                     {'name': '24. Zusammen leben - Alleine sterben (2)',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e24.mp4',
                      'genre': 'Crime'},
                     {'name': '25. Outtakes',
                      'thumb': '',
                      'video': 'https://archive.org/download/Lost-S02/isd-lostxvid-s02e25.mp4',
                      'genre': 'Crime'}
                    ],
                    
                    'Staffel 3': [{'name': '01. Die zwei Stadte',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/Lost003.jpg',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e01.mp4',
                      'genre': 'Crime'},
                     {'name': '02. Die glaserne Ballerina',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e02.mp4',
                      'genre': 'Crime'},
                     {'name': '03. Der Auftrag',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e03.mp4',
                      'genre': 'Crime'},
                     {'name': '04. Jeder fur sich',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e04.mp4',
                      'genre': 'Crime'},
                     {'name': '05. Der Preis des Lebens',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e05.mp4',
                      'genre': 'Crime'},
                     {'name': '06. Ja, ich will',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e06.mp4',
                      'genre': 'Crime'},
                     {'name': '07. Nicht in Portland',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e07.mp4',
                      'genre': 'Crime'},
                     {'name': '08. Erinnerungsfetzen',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e08.mp4',
                      'genre': 'Crime'},
                     {'name': '09. Fremd in fremden Land',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e09.mp4',
                      'genre': 'Crime'},
                     {'name': '10. Tricia Tanaka ist tot',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e10.mp4',
                      'genre': 'Crime'},
                     {'name': '11. Die Flamme',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e11.mp4',
                      'genre': 'Crime'},
                     {'name': '12. Luftpost',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e12.mp4',
                      'genre': 'Crime'},
                     {'name': '13. Der Mann aus Tallahassee',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e13.mp4',
                      'genre': 'Crime'},
                     {'name': '14. Expos�',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e14.mp4',
                      'genre': 'Crime'},
                     {'name': '15. Allein',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e15.mp4',
                      'genre': 'Crime'},
                      {'name': '16. Eine von uns',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e16.mp4',
                      'genre': 'Crime'},
                      {'name': '17. Catch 22',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e17.mp4',
                      'genre': 'Crime'},
                      {'name': '18. Tag der Empfangnis',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e18.mp4',
                      'genre': 'Crime'},
                      {'name': '19. Im Loch',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e19.mp4',
                      'genre': 'Crime'},
                      {'name': '20. Der Mann hinter dem Vorhang',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e20.mp4',
                      'genre': 'Crime'},
                      {'name': '21. Greatest Hits',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e21.mp4',
                      'genre': 'Crime'},
                     {'name': '22. Hinter dem Spiegel - Teil 1',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e22.mp4',
                      'genre': 'Crime'},
                     {'name': '23. Hinter dem Spiegel - Teil 2',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS03/itg-lost-s03e23.mp4',
                      'genre': 'Crime'}
                    ],

                    
                    'Staffel 4': [{'name': '01. Der Anfang vom Ende',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/Lost004.jpg',
                      'video': 'https://archive.org/download/LostS04/etm-lost-s04e01.mp4',
                      'genre': 'Crime'},
                     {'name': '02. Für tot erklärt',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS04/etm-lost-s04e02.mp4',
                      'genre': 'Crime'},
                     {'name': '03. Der Ökonom',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS04/etm-lost-s04e03.mp4',
                      'genre': 'Crime'},
                     {'name': '04. Der Deal',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS04/etm-lost-s04e04.mp4',
                      'genre': 'Crime'},
                     {'name': '05. Die Konstante',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS04/etm-lost-s04e05.mp4',
                      'genre': 'Crime'},
                     {'name': '06. Die andere Frau',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS04/etm-lost-s04e06.mp4',
                      'genre': 'Crime'},
                     {'name': '07. Ji Yeon',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS04/etm-lost-s04e07.mp4',
                      'genre': 'Crime'},
                     {'name': '08. Triff Kevin Johnson',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS04/etm-lost-s04e08.mp4',
                      'genre': 'Crime'},
                     {'name': '09. Konturen der Zukunft',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS04/etm-lost-s04e09.mp4',
                      'genre': 'Crime'},
                     {'name': '10. Die Operation',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS04/etm-lost-s04e10.mp4',
                      'genre': 'Crime'},
                     {'name': '11. Hüttenzauber',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS04/etm-lost-s04e11.mp4',
                      'genre': 'Crime'},
                     {'name': '12. Die Rückkehr (1)',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS04/etm-lost-s04e12.mp4',
                      'genre': 'Crime'},
                     {'name': '13. Die Rückkehr (2)',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS04/etm-lost-s04e13.mp4',
                      'genre': 'Crime'},
                     {'name': '14. Die Rückkehr (3)',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS04/etm-lost-s04e14.mp4',
                      'genre': 'Crime'}
                      
                    ],
                    
                    'Staffel 5': [{'name': '01. Glaube und Wissenschaft',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/Lost005.jpg',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e01.mp4',
                      'genre': 'Crime'},
                     {'name': '02. Treibholz',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e02.mp4',
                      'genre': 'Crime'},
                     {'name': '03. Orientierung',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e03.mp4',
                      'genre': 'Crime'},
                     {'name': '04. Alle hassen Hugo',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e04.mp4',
                      'genre': 'Crime'},
                     {'name': '05. Gefunden',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e05.mp4',
                      'genre': 'Crime'},
                     {'name': '06. Verlassen',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e06.mp4',
                      'genre': 'Crime'},
                     {'name': '07. Die anderen 48 Tage',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e07.mp4',
                      'genre': 'Crime'},
                     {'name': '08. Kollision',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e08.mp4',
                      'genre': 'Crime'},
                     {'name': '09. Was Kate getan hat',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e09.mp4',
                      'genre': 'Crime'},
                     {'name': '10. Psalm 23',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e10.mp4',
                      'genre': 'Crime'},
                     {'name': '11. Jagdgesellschaft',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e11.mp4',
                      'genre': 'Crime'},
                     {'name': '12. Feuer und Wasser',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e12.mp4',
                      'genre': 'Crime'},
                     {'name': '13. Langer Atem',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e13.mp4',
                      'genre': 'Crime'},
                     {'name': '14. Einer von Ihnen',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e14.mp4',
                      'genre': 'Crime'},
                     {'name': '15. Mutterschutz',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e15.mp4',
                      'genre': 'Crime'},
                      {'name': '16. Die ganze Wahrheit',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e16.mp4',
                      'genre': 'Crime'},
                      {'name': '17. Verriegelt',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e17.mp4',
                      'genre': 'Crime'},
                      {'name': '18. Dave',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e18.mp4',
                      'genre': 'Crime'},
                      {'name': '19. S.O.S.',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e19.mp4',
                      'genre': 'Crime'},
                      {'name': '20. Zwei für unterwegs',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e20.mp4',
                      'genre': 'Crime'},
                      {'name': '21. Fragezeichen',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e21.mp4',
                      'genre': 'Crime'},
                     {'name': '22. Drei Minuten',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e22.mp4',
                      'genre': 'Crime'},
                     {'name': '23. Zusammen leben - Alleine sterben (1)',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e23.mp4',
                      'genre': 'Crime'},
                     {'name': '24. Zusammen leben - Alleine sterben (2)',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e24.mp4',
                      'genre': 'Crime'},
                     {'name': '25. Outtakes',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS05/exp-lostxvid-s05e25.mp4',
                      'genre': 'Crime'}
                    ],

                      
                      'Staffel 6': [{'name': '01. Die zwei St�dte',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/Lost006.jpg',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e01.mp4',
                      'genre': 'Crime'},
                     {'name': '02. Die gl�serne Ballerina',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e02.mp4',
                      'genre': 'Crime'},
                     {'name': '03. Der Auftrag',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e03.mp4',
                      'genre': 'Crime'},
                     {'name': '04. Jeder für sich',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e04.mp4',
                      'genre': 'Crime'},
                     {'name': '05. Der Preis des Lebens',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e05.mp4',
                      'genre': 'Crime'},
                     {'name': '06. Ja, ich will',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e06.mp4',
                      'genre': 'Crime'},
                     {'name': '07. Nicht in Portland',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e07.mp4',
                      'genre': 'Crime'},
                     {'name': '08. Erinnerungsfetzen',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e08.mp4',
                      'genre': 'Crime'},
                     {'name': '09. Fremd in fremden Land',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e09.mp4',
                      'genre': 'Crime'},
                     {'name': '10. Tricia Tanaka ist tot',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e10.mp4',
                      'genre': 'Crime'},
                     {'name': '11. Die Flamme',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e11.mp4',
                      'genre': 'Crime'},
                     {'name': '12. Luftpost',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e12.mp4',
                      'genre': 'Crime'},
                     {'name': '13. Der Mann aus Tallahassee',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e13.mp4',
                      'genre': 'Crime'},
                     {'name': '14. Expos�',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e14.mp4',
                      'genre': 'Crime'},
                     {'name': '15. Allein',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e15.mp4',
                      'genre': 'Crime'},
                      {'name': '16. Eine von uns',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e16.mp4',
                      'genre': 'Crime'},
                      {'name': '17. Catch 22',
                      'thumb': '',
                      'video': 'https://archive.org/download/LostS06/deli-lostxvid-s06e17.mp4',
                      'genre': 'Crime'}
                      
                     ]}


def get_url(**kwargs):
    """
    Create a URL for calling the plugin recursively from the given set of keyword arguments.

    :param kwargs: "argument=value" pairs
    :type kwargs: dict
    :return: plugin call URL
    :rtype: str
    """
    return '{0}?{1}'.format(_url, urlencode(kwargs))


def get_categories():
    """
    Get the list of video categories.

    Here you can insert some parsing code that retrieves
    the list of video categories (e.g. 'Movies', 'TV-shows', 'Documentaries' etc.)
    from some site or server.

    .. note:: Consider using `generator functions <https://wiki.python.org/moin/Generators>`_
        instead of returning lists.

    :return: The list of video categories
    :rtype: types.GeneratorType
    """
    return VIDEOS.iterkeys()


def get_videos(category):
    """
    Get the list of videofiles/streams.

    Here you can insert some parsing code that retrieves
    the list of video streams in the given category from some site or server.

    .. note:: Consider using `generators functions <https://wiki.python.org/moin/Generators>`_
        instead of returning lists.

    :param category: Category name
    :type category: str
    :return: the list of videos in the category
    :rtype: list
    """
    return VIDEOS[category]


def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_handle, 'My Video Collection')
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_handle, 'videos')
    # Get video categories
    categories = get_categories()
    # Iterate through categories
    for category in categories:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=category)
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': VIDEOS[category][0]['thumb'],
                          'icon': VIDEOS[category][0]['thumb'],
                          'fanart': VIDEOS[category][0]['thumb']})
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # https://codedocs.xyz/xbmc/xbmc/group__python__xbmcgui__listitem.html#ga0b71166869bda87ad744942888fb5f14
        # 'mediatype' is needed for a skin to display info for this ListItem correctly.
        list_item.setInfo('video', {'title': category,
                                    'genre': category,
                                    'mediatype': 'video'})
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        url = get_url(action='listing', category=category)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def list_videos(category):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: Category name
    :type category: str
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_handle, category)
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_handle, 'videos')
    # Get the list of videos in the category.
    videos = get_videos(category)
    # Iterate through videos.
    for video in videos:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=video['name'])
        # Set additional info for the list item.
        # 'mediatype' is needed for skin to display info for this ListItem correctly.
        list_item.setInfo('video', {'title': video['name'],
                                    'genre': video['genre'],
                                    'mediatype': 'video'})
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
        # Set 'IsPlayable' property to 'true'.
        # This is mandatory for playable items!
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/wp-content/uploads/2017/04/crab.mp4
        url = get_url(action='play', video=video['video'])
        # Add the list item to a virtual Kodi folder.
        # is_folder = False means that this item won't open any sub-list.
        is_folder = False
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def play_video(path):
    """
    Play a video by the provided path.

    :param path: Fully-qualified video URL
    :type path: str
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            list_videos(params['category'])
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_video(params['video'])
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception. This helps to catch coding errors,
            # e.g. typos in action names.
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_categories()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])

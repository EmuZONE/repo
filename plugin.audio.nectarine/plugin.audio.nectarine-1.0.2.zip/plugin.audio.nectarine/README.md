Nectarine Demoscene Radio XBMC Plugin
=====================================

Stream the best of demoscene music from Nectarine Demoscene Radio (www.scenemusic.net) directly from XBMC using this fan-made plugin.

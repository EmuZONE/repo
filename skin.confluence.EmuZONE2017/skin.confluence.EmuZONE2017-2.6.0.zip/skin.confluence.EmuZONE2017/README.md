# skin.confluence.EmuZONE2017

Ported from Confluence v2.5.9 used on Jarvis 16.1 RC

25 Shortcuts für Video Plugins, 15 für Musik und Programme.  
Debug Grafik inklusive.


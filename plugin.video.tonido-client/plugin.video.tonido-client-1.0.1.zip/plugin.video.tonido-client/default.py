import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,xbmc,xbmcaddon,os,hashlib,cookielib
from t0mm0.common.addon import Addon
from resources.lib import net
from resources.lib import downloader

net =           net.Net()
addon_id =      'plugin.video.tonido-client'
AddonName =     'Tonido Client'
selfAddon =     xbmcaddon.Addon(id=addon_id)
datapath=       xbmc.translatePath(selfAddon.getAddonInfo('profile'))
addon =         Addon(addon_id, sys.argv)
fanart =        xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon =          xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
folder =        xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art', 'folder.png'))
status =        xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art', 'status.png'))
extensions =    xbmc.translatePath(os.path.join('special://home/addons/' + addon_id+'/resources','extensions.txt'))
try:os.mkdir(datapath)
except:pass
file_var =      open(xbmc.translatePath(os.path.join(datapath, 'cookie.lwp')), "a")
cookie_file =   os.path.join(os.path.join(datapath,''), 'cookie.lwp')
dialog =        xbmcgui.Dialog()
     
def Start():
        user = selfAddon.getSetting('username')
        passw = selfAddon.getSetting('password')
        if user == '' or passw == '':
                dialog = xbmcgui.Dialog()
                ret = dialog.yesno('[COLOR gold]Tonido[/COLOR]', 'You need a Tonido account to use this addon','If you have an account click Login','or visit http://www.tonido.com/ for information','Cancel','Login')
                if ret == 1:
                        keyb = xbmc.Keyboard('', 'Enter Username')
                        keyb.doModal()
                        if (keyb.isConfirmed()):
                                username = keyb.getText()
                                selfAddon.setSetting('username',username)
                                keyb = xbmc.Keyboard('', 'Enter Password:')
                                keyb.doModal()
                                if (keyb.isConfirmed()):
                                        password = keyb.getText()
                                        hash_object = hashlib.sha1(password)
                                        hex_dig = hash_object.hexdigest()
                                        selfAddon.setSetting('password',hex_dig)
                else:quit()
        LoginUser()
                                            
def LoginUser():
        url='http://%s.tonidoid.com/core/loginprofile' %(selfAddon.getSetting('username'))
        post_data = {}
        post_data['profile'] = selfAddon.getSetting('username')
        post_data['password'] = selfAddon.getSetting('password')
        authresponse=net.http_POST(url,post_data).content
        net.save_cookies(cookie_file)
        if '<result>1</result>' in authresponse:
                GetFileList('')
                url='http://%s.tonidoid.com/core/getsystemstatus' %(selfAddon.getSetting('username'))                
                addLink('[COLOR gold]Status Information[/COLOR]',url,3,status,fanart,playable=False)
                xbmc.executebuiltin('Container.SetViewMode(500)')
        else:
                dialog.ok(AddonName, 'Failed','There was a problem logging in','Please check your credentials')
                quit()

def DownloadLocal(name,url):
        net.set_cookies(cookie_file)
        tokenurl='http://%s.tonidoid.com/core/getauthurl'%(selfAddon.getSetting('username'))
        tokens=net.http_GET(tokenurl).content
        url=url+tokens
        name=urllib.unquote(name)
        dp = xbmcgui.DialogProgress()
        dl_loc = dialog.browse(0, 'Select folder to download to', 'myprograms')
        lib=os.path.join(dl_loc, name)
        dp.create('Downloading','','', 'Please Wait')
        downloader.download(url, lib, dp)
        dp.close()
        dialog.ok('Download Complete','The file was downloaded to:',dl_loc)
        
def SytemStatus(url):
        net.set_cookies(cookie_file)
        sytemstatus=net.http_GET(url).content
        username = re.compile('<currentprofile>(.+?)</currentprofile>').findall(sytemstatus)[0]
        serveros = re.compile('<OS>(.+?)</OS>').findall(sytemstatus)[0]
        serverversion = re.compile('<appversion>(.+?)</appversion>').findall(sytemstatus)[0]
        serverupdate = re.compile('<needsupdate>(.+?)</needsupdate>').findall(sytemstatus)[0]
        if serverupdate == '0':serverupdate='No'
        else:serverupdate='Yes'
        serveruptime = re.compile('<uptime>(.+?)</uptime>').findall(sytemstatus)[0]
        serveruptotaltime = re.compile('<totaluptime>(.+?)</totaluptime>').findall(sytemstatus)[0]
        serverinternalip = re.compile('<privateip>(.+?)</privateip>').findall(sytemstatus)[0]
        serverurl = re.compile('<serverurl>(.+?)</serverurl>').findall(sytemstatus)[0]
        licencelevel = re.compile('<licenselevel>(.+?)</licenselevel>').findall(sytemstatus)[0]
        licenceexpires = re.compile('<licensedtill>(.+?)</licensedtill>').findall(sytemstatus)[0]
        licencetype = re.compile('<licensestring>(.+?)</licensestring>').findall(sytemstatus)[0]
        text     ='[COLOR gold]Account:[/COLOR]    '+username+'\n\n'
        text=text+'[COLOR gold]Server OS:[/COLOR]    '+serveros+'\n\n'
        text=text+'[COLOR gold]Server Version:[/COLOR]    '+serverversion+'\n\n'
        text=text+'[COLOR gold]Server Update Available:[/COLOR]    '+serverupdate+'\n\n'
        text=text+'[COLOR gold]Server Internal IP:[/COLOR]    '+serverinternalip+'\n\n'
        text=text+'[COLOR gold]Server URL:[/COLOR]    '+serverurl+'\n\n'
        text=text+'[COLOR gold]Server Uptime:[/COLOR]    '+serveruptime+'\n\n'
        text=text+'[COLOR gold]Server Total Uptime:[/COLOR]    '+serveruptotaltime+'\n\n'
        text=text+'[COLOR gold]Server Licence:[/COLOR]    '+licencetype+'\n\n'
        text=text+'[COLOR gold]Server Licence Type:[/COLOR]    '+licencelevel+'\n\n'
        text=text+'[COLOR gold]Server Licenced Till:[/COLOR]    '+licenceexpires+'\n\n'
        showText('[COLOR gold]Status Information[/COLOR]', text)

def GetFileTypes(rfile):
        ext=rfile.split('.')[-1]
        file = open(extensions, 'r')
        data = file.read()
        if rfile=='image':
                images=re.compile('<image>(.+?)</image>').findall(data.replace('\n','').lower())[0]
                image=re.compile('<(.+?)>').findall(images)
                return image
        else:
                if ext.lower() in data.lower(): return True
                else: return False

 
def GetFileList(url):
        net.set_cookies(cookie_file)
        post_data = {}
        post_data['path'] = url
        url='http://%s.tonidoid.com/core/getfilelist' %(selfAddon.getSetting('username'))
        filelistresponse=net.http_POST(url,post_data).content
        entries=re.compile('<entry>(.+?)</entry>').findall(filelistresponse)
        for entry in entries:
                path=re.compile('<path>(.+?)</path>').findall(entry)[0].replace('&apos;',"'").replace('&amp;',"&")
                dirpath=urllib.quote(cleanHex(re.compile('<dirpath>(.+?)</dirpath>').findall(entry)[0].replace('&apos;',"'").replace('&amp;',"&")))
                name=urllib.quote(cleanHex(re.compile('<name>(.+?)</name>').findall(entry)[0].replace('&apos;',"'").replace('&amp;',"&")))
                type=re.compile('<type>(.+?)</type>').findall(entry)[0]
                ext=re.compile('<ext>(.+?)</ext>').findall(entry)[0]
                try:
                        fullsize=float(re.compile('<fullsize>(.+?)</fullsize>').findall(entry)[0])
                        fullsize=format(float(fullsize/1024/1024), '.2f')
                except:pass
                if type == 'dir':
                        prettyname='[COLOR blue][ [/COLOR]'+urllib.unquote(name)+' [COLOR blue]][/COLOR]'
                        addDir(prettyname,path,1,folder,fanart,description='')
                elif type == 'file':
                        metadata=meta(name,dirpath)
                        iconimage='http://%s.tonidoid.com/core/getfsthumbimage?name=%s&width=600&height=600' %(selfAddon.getSetting('username'),dirpath+name)
                        iconimage=iconimage+'|Cookie=%s'%getCookiesString()
                        prettyname=urllib.unquote(metadata['Title'])+'[COLOR blue] ('+str(fullsize)+'mb)[/COLOR] '
                        exttest=GetFileTypes(name)
                        images=GetFileTypes('image')
                        extension=name.split('.')[-1]
                        if extension in images:
                                addLink(prettyname,iconimage,5,iconimage,fanart,name,dirpath,playable=False)       
                        elif exttest==True:addLink(prettyname,path,2,iconimage,fanart,name,dirpath)     
                        else:addLink(prettyname,path,2,iconimage,fanart,name,dirpath,playable=False)

def meta(name,dirpath):
        meta={}
        url=dirpath+name
        net.set_cookies(cookie_file)
        metaurl='http://%s.tonidoid.com/core/getmetadatainfo?name=%s'%(selfAddon.getSetting('username'),url)
        response=net.http_GET(metaurl).content        
        try:title = cleanHex(re.compile('<title>(.+?)</title>').findall(response)[0].replace('&apos;',"'").replace('&amp;',"&"))
        except:title=name
        meta['Title'] = title
        try:artist = re.compile('<artist>(.+?)</artist>').findall(response)[0]
        except:artist=''
        meta['Artist'] = artist
        try:album = re.compile('<album>(.+?)</album>').findall(response)[0]
        except:album=''
        meta['Album'] = album
        try:year = re.compile('<year>(.+?)</year>').findall(response)[0]
        except:year=''
        meta['Year'] = year
        print meta
        return meta

def Play(name,filename,dirpath,iconimage):
        metadata=meta(filename,dirpath)
        exttest=GetFileTypes(filename)
        if exttest==True:
                net.set_cookies(cookie_file)
                url='http://%s.tonidoid.com/core/getauthurl'%(selfAddon.getSetting('username'))
                tokens=net.http_GET(url).content
                url='http://%s.tonidoid.com/download/%s?filepath=%s&filename=%s&%s' %(selfAddon.getSetting('username'),filename,dirpath+filename,filename,tokens)
                ok=True
                liz=xbmcgui.ListItem(metadata['Title'], iconImage="DefaultFolder.png", thumbnailImage=iconimage)
                liz.setInfo( type="Audio", infoLabels=metadata )
                ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
                liz.setPath(url)
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        if exttest==False:
                ret = dialog.yesno(AddonName,'Selected filetype is not viewable in Kodi', '', 'Do you want to download locally instead?')
                if ret==1:
                        dlurl='http://%s.tonidoid.com/download/%s?filepath=%s&filename=%s&' %(selfAddon.getSetting('username'),filename,dirpath+filename,filename)
                        DownloadLocal(filename,dlurl)
                
def ShowImage(url):
        string = "ShowPicture(%s)" %url
        xbmc.executebuiltin(string)
     
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

def addDir(name,url,mode,iconimage,fanart,description=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&filename="+str(filename)
        ok=True
        liz=xbmcgui.ListItem(name.strip(), iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name})
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addLink(name,url,mode,iconimage,fanart,filename='',dirpath='',playable=True):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&filename="+str(filename)+"&iconimage="+urllib.quote_plus(iconimage)+"&dirpath="+str(dirpath)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        if playable==True:
                liz.setProperty("IsPlayable","true")
        liz.setInfo( type="Video", infoLabels={ "Title": name})
        dlurl='http://%s.tonidoid.com/download/%s?filepath=%s&filename=%s&' %(selfAddon.getSetting('username'),filename,dirpath+filename,filename)
        cmenu=[]
	cmenu.append(('Download File Locally', 'XBMC.RunPlugin(%s)' % addon.build_plugin_url({'mode': 4, 'url':dlurl, 'name':filename})))
        liz.addContextMenuItems(cmenu, replaceItems=False) 
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok

def getCookiesString():
    cookieString=""
    try:
        cookieJar = cookielib.LWPCookieJar()
        cookieJar.load(cookie_file,ignore_discard=True)
        for index, cookie in enumerate(cookieJar):
            cookieString+=cookie.name + "=" + cookie.value +";"
    except: 
        import sys,traceback
        traceback.print_exc(file=sys.stdout)
    return cookieString[:-1]

def showText(heading, text):
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(500)
    win = xbmcgui.Window(id)
    retry = 50
    while (retry > 0):
	try:
	    xbmc.sleep(10)
	    retry -= 1
	    win.getControl(1).setLabel(heading)
	    win.getControl(5).setText(text)
	    return
	except:
	    pass
     
def cleanHex(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
        else: return unichr(int(text[2:-1])).encode('utf-8')
    try :return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8')).replace('&amp;',' & ')
    except:return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8')).replace('&amp;',' & ')
    
params=get_params(); url=None; name=None; mode=None; iconimage=None; filename=None; dirpath=None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: filename=str(params["filename"])
except: pass
try: dirpath=str(params["dirpath"])
except: pass

if mode==None or url==None or len(url)<1: Start()
elif mode==1: GetFileList(url)
elif mode==2: Play(name,filename,dirpath,iconimage)
elif mode==3: SytemStatus(url)
elif mode==4: DownloadLocal(name,url)
elif mode==5: ShowImage(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))


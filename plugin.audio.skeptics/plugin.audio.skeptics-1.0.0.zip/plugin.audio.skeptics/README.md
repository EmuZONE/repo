The Skeptics Guide to the Universe
-------------------------------------------
Listen to The Skeptics Guide to the Galaxy on Kodi. 

Setup/Installation: 
The plugin should be installed through the official Kodi addon repository.

Contact:
dtoumbourou@gmail.com

The Skeptics Guide to the Universe: 
keptics’ Guide to the Universe is produced by SGU Productions, LLC – dedicated to promoting critical thinking, reason, and the public understanding of science through online and other media. The first episode of the SGU podcast went online on May 4th, 2005. It soon became a popular science/skeptical podcast, and remains one of the most popular science podcasts on iTunes.

-------------------------------------------
To help support the SGU and all the wonderful work they do you can become a member.
For further details please visit the SGU website at http://www.theskepticsguide.org

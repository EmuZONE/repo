
# screensaver.atv4
## Apple Aerial screensavers for Kodi

This addon lets you add the new apple tv 4 screensavers to Kodi Entertainment Center

# Screenshots

![Screenshot screensaver](http://s11.postimg.org/g7u5s4jj7/Screen_Shot_2015_11_06_at_23_58_39.png)

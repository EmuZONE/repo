# -*- coding: utf-8 -*-
# Module: default
# Author: Roman V. M.
# Created on: 28.11.2014
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
from urllib import urlencode
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

# Free sample videos are provided by www.vidsplay.com
# Here we use a fixed set of properties simply for demonstrating purposes
# In a "real life" plugin you will need to get info and links to video files/streams
# from some web-site or online service.
VIDEOS = {'Die Märchenbraut': [{'name': '01. Der Wolf ist tot',
                       'thumb': 'https://images-eu.ssl-images-amazon.com/images/I/51qaYEvB%2BrL.jpg',
                       'video': 'https://archive.org/download/yggdrazil_hotmail_DMB/S01E01.mp4',
                       'genre': 'Fantasy'},
                      {'name': '02. Rumburaks Rache',
                       'thumb': 'https://images-eu.ssl-images-amazon.com/images/I/51qaYEvB%2BrL.jpg',
                       'video': 'https://archive.org/download/yggdrazil_hotmail_DMB/S01E02.mp4',
                       'genre': 'Fantasy'},
                       {'name': '03. Liebe auf den ersten Blick',
                       'thumb': 'https://images-eu.ssl-images-amazon.com/images/I/51qaYEvB%2BrL.jpg',
                       'video': 'https://archive.org/download/yggdrazil_hotmail_DMB/S01E03.mp4',
                       'genre': 'Fantasy'},
                       {'name': '04. Der Dackel Herr Maier',
                       'thumb': 'https://images-eu.ssl-images-amazon.com/images/I/51qaYEvB%2BrL.jpg',
                       'video': 'https://archive.org/download/yggdrazil_hotmail_DMB/S01E04.mp4',
                       'genre': 'Fantasy'},
                       {'name': '05. Arabella auf der Flucht',
                       'thumb': 'https://images-eu.ssl-images-amazon.com/images/I/51qaYEvB%2BrL.jpg',
                       'video': 'https://archive.org/download/yggdrazil_hotmail_DMB/S01E05.mp4',
                       'genre': 'Fantasy'},
                       {'name': '06. Wunschring und Zaubermantel',
                       'thumb': 'https://images-eu.ssl-images-amazon.com/images/I/51qaYEvB%2BrL.jpg',
                       'video': 'https://archive.org/download/yggdrazil_hotmail_DMB/S01E06.mp4',
                       'genre': 'Fantasy'},
                       {'name': '07. Märchen für den Müll',
                       'thumb': 'https://images-eu.ssl-images-amazon.com/images/I/51qaYEvB%2BrL.jpg',
                       'video': 'https://archive.org/download/yggdrazil_hotmail_DMB/S01E07.mp4',
                       'genre': 'Fantasy'},
                       {'name': '08. Hänsel und Gretel',
                       'thumb': 'https://images-eu.ssl-images-amazon.com/images/I/51qaYEvB%2BrL.jpg',
                       'video': 'https://archive.org/download/yggdrazil_hotmail_DMB/S01E08.mp4',
                       'genre': 'Fantasy'},
                       {'name': '09. Verhexte Autos',
                       'thumb': 'https://images-eu.ssl-images-amazon.com/images/I/51qaYEvB%2BrL.jpg',
                       'video': 'https://archive.org/download/yggdrazil_hotmail_DMB/S01E09.mp4',
                       'genre': 'Fantasy'},
                       {'name': '10. Rumburaks gro�e Chance',
                       'thumb': 'https://images-eu.ssl-images-amazon.com/images/I/51qaYEvB%2BrL.jpg',
                       'video': 'https://archive.org/download/yggdrazil_hotmail_DMB/S01E10.mp4',
                       'genre': 'Fantasy'},
                       {'name': '11. Ein Taxi und fünf Generäle',
                       'thumb': 'https://images-eu.ssl-images-amazon.com/images/I/51qaYEvB%2BrL.jpg',
                       'video': 'https://archive.org/download/yggdrazil_hotmail_DMB/S01E11.mp4',
                       'genre': 'Fantasy'},
                       {'name': '12. Im Verlies der Geisterburg',
                       'thumb': 'https://images-eu.ssl-images-amazon.com/images/I/51qaYEvB%2BrL.jpg',
                       'video': 'https://archive.org/download/yggdrazil_hotmail_DMB/S01E12.mp4',
                       'genre': 'Fantasy'},
                      {'name': '13. Glockliches Ende',
                       'thumb': 'https://images-eu.ssl-images-amazon.com/images/I/51qaYEvB%2BrL.jpg',
                       'video': 'https://archive.org/download/yggdrazil_hotmail_DMB/S01E13.mp4',
                       'genre': 'Fantasy'}
                      ],
            'Die Rückkehr der Märchenbraut': [{'name': '01. Riesen-Sorgen',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E01.mp4',
                      'genre': 'Fantasy'},
                     {'name': '02. Ab in die Zukunft',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E02.mp4',
                      'genre': 'Fantasy'},
                      {'name': '03. Zauber ohne Ende',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E03.mp4',
                      'genre': 'Fantasy'},
                      {'name': '04. Pleiten, Pech und Peter',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E04.mp4',
                      'genre': 'Fantasy'},
                      {'name': '05. Die Reise zum Apfel',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E05.mp4',
                      'genre': 'Fantasy'},
                      {'name': '06. Apfel durch die Wand',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E06.mp4',
                      'genre': 'Fantasy'},
                      {'name': '07. Die Helden drücken sich',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E07.mp4',
                      'genre': 'Fantasy'},
                      {'name': '08. Die Opi-Babys',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E08.mp4',
                      'genre': 'Fantasy'},
                      {'name': '09. Achtung, fertig � los',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E09.mp4',
                      'genre': 'Fantasy'},
                      {'name': '10. Neue Freunde, neue Feinde',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E10.mp4',
                      'genre': 'Fantasy'},
                      {'name': '11. Der Dreh mit dem Ring',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E11.mp4',
                      'genre': 'Fantasy'},
                      {'name': '12. Dumme Ziege',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E12.mp4',
                      'genre': 'Fantasy'},
                      {'name': '13. Die Motz-Kassette',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E13.mp4',
                      'genre': 'Fantasy'},
                      {'name': '14. Wer ist wer?',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E14.mp4',
                      'genre': 'Fantasy'},
                      {'name': '15. König! Na und!',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E15.mp4',
                      'genre': 'Fantasy'},
                      {'name': '16. Nichts wie weg!',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E16.mp4',
                      'genre': 'Fantasy'},
                      {'name': '17. Eingebuddelt - Ausgebuddelt',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E17.mp4',
                      'genre': 'Fantasy'},
                      {'name': '18. Doppel-Papp',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E18.mp4',
                      'genre': 'Fantasy'},
                      {'name': '19. Achtung � die Kinder kommen',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E19.mp4',
                      'genre': 'Fantasy'},
                      {'name': '20. Um ein Haar am Galgen',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E20.mp4',
                      'genre': 'Fantasy'},
                      {'name': '21. Alle Macht den Bösen?',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E21.mp4',
                      'genre': 'Fantasy'},
                      {'name': '22. Krach um die Insel',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E22.mp4',
                      'genre': 'Fantasy'},
                      {'name': '23. Rettungsring und Apfelkuchen',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E23.mp4',
                      'genre': 'Fantasy'},
                      {'name': '24. Mit Riesen auf Reisen',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E24.mp4',
                      'genre': 'Fantasy'},
                      {'name': '25. Aus der Traum?',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E25.mp4',
                      'genre': 'Fantasy'},
                     {'name': '26. Rabe gut, alles gut',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/DRDMB.jpg',
                      'video': 'https://archive.org/download/DRDMB/S01E26.mp4',
                      'genre': 'Fantasy'}
                     ],
                     
                     'Highlander - Es kann nur einen geben': [{'name': 'Highlander - Es kann nur einen geben',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/shokxone_highlander.jpg',
                      'video': 'https://archive.org/download/HellRaiserGerman/Highlander-EsKannNurEinenGeben.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Highlander II': [{'name': 'Highlander II',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/HL2.jpg',
                      'video': 'https://archive.org/download/HellRaiserGerman/Highlander%20II%20-%20Die%20R%C3%BCckkehr.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Highlander III': [{'name': 'Highlander III',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/HL3.jpg',
                      'video': 'https://archive.org/download/HellRaiserGerman/Highlander%20III.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Robocop 1': [{'name': 'Robocop 1',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/RC1.jpg',
                      'video': 'https://archive.org/download/Robocop1-3UnC/Robocop%20%281987%29.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Robocop 2': [{'name': 'Robocop 2',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/RC2.jpg',
                      'video': 'https://archive.org/download/Robocop1-3UnC/Robocop%202.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Robocop 3': [{'name': 'Robocop 3',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/RC3.jpg',
                      'video': 'https://archive.org/download/Robocop1-3UnC/Robocop%203.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Hellraiser Part I': [{'name': 'Hellraiser - Das Tor zur Hoelle',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/HR1.jpg',
                      'video': 'https://archive.org/download/HellRaiserGerman/Hellraiser-DasTorZurHlle1987.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Hellraiser Part II': [{'name': 'Hellbound: Hellraiser',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/HR2.jpg',
                      'video': 'https://archive.org/download/HellRaiserGerman/HellboundHellraiserIi1988.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Hellraiser Part III': [{'name': 'Hellraiser 3 - Hell on Earth',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/HR3.jpg',
                      'video': 'https://archive.org/download/HellRaiserGerman/Hellraiser%20III%20-%20Hell%20on%20Earth.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Hellraiser Part IV': [{'name': 'Hellraiser 4 - Bloodlines',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/HR4.jpg',
                      'video': 'https://archive.org/download/HellRaiserGerman/Hellraiser%20IV%20-%20Bloodline.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Hellraiser Part V': [{'name': 'Hellraiser 5 - Inferno',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/HR5.jpg',
                      'video': 'https://archive.org/download/HellRaiserGerman/Hellraiser%20V%20-%20Inferno.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Hellraiser Part VI': [{'name': 'Hellraiser 6 - Hellseeker',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/HR6.jpg',
                      'video': 'https://archive.org/download/HellRaiserGerman/Hellraiser%20VI%20-%20Hellseeker.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Hellraiser Part VII': [{'name': 'Hellraiser 7 - Deader',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/HR7.jpg',
                      'video': 'https://archive.org/download/HellRaiserGerman/Hellraiser%20VII%20-%20Deader.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Hellraiser Part VIII': [{'name': 'Hellraiser 8 - Hellworld',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/HR8.jpg',
                      'video': 'https://archive.org/download/HellRaiserGerman/Hellraiser%20VIII%20-%20Hellworld.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Hellraiser Part IX': [{'name': 'Hellraiser 9 - Revelations',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/HR9.jpg',
                      'video': 'https://archive.org/download/HellRaiserGerman/Hellraiser%20IX%20-%20Revelations.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Return to Hounted Hill': [{'name': 'Return to Hounted Hill',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/HHill.jpg',
                      'video': 'https://archive.org/download/HellRaiserGerman/Hounted%20Hill%20-%20Die%20R%C3%BCckkehr%20in%20das%20Haus%20des%20Schreckens%20.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Zum Teufel mit der Penne': [{'name': 'Zum Teufel mit der Penne',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/HDSB2.jpg',
                      'video': 'https://archive.org/download/DieLmmelV.d.ErstenBankVol.1/Zum%20Teufel%20mit%20der%20Penne%20%281968%29.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'Hurra die Schule brennt': [{'name': 'Hurra die Schule brennt',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/HDSB.jpg',
                      'video': 'https://archive.org/download/DieLmmelV.d.ErstenBankVol.1/Hurra%2C%20die%20Schule%20brennt.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
                      'House of the Dead': [{'name': 'House of the Dead',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/HOD.jpg',
                      'video': 'https://archive.org/download/HellRaiserGerman/House%20of%20the%20Dead.mp4',
                      'genre': 'Fantasy'}
                      
                      ],
                      
            'Der Exorzist': [{'name': '01. Janus',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/TE02.jpg',
                      'video': 'https://archive.org/download/TheExo/S02E01.mp4',
                      'genre': 'Horror'},
                     {'name': '02. Safe As Houses',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/TE02.jpg',
                      'video': 'https://archive.org/download/TheExo/S02E02.mp4',
                      'genre': 'Horror'},
                      {'name': '03. Unclean',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/TE02.jpg',
                      'video': 'https://archive.org/download/TheExo/S02E03.mp4',
                      'genre': 'Horror'},
                      {'name': '04. Safe As Houses',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/TE02.jpg',
                      'video': 'https://archive.org/download/TheExo/S02E04.mp4',
                      'genre': 'Horror'},
                      {'name': '05. Safe As Houses',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/TE02.jpg',
                      'video': 'https://archive.org/download/TheExo/S02E05.mp4',
                      'genre': 'Horror'},
                      {'name': '06. Safe As Houses',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/TE02.jpg',
                      'video': 'https://archive.org/download/TheExo/S02E06.mp4',
                      'genre': 'Horror'},
                      {'name': '07. Safe As Houses',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/TE02.jpg',
                      'video': 'https://archive.org/download/TheExo/S02E07.mp4',
                      'genre': 'Horror'},
                      {'name': '08. Safe As Houses',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/TE02.jpg',
                      'video': 'https://archive.org/download/TheExo/S02E08.mp4',
                      'genre': 'Horror'},
                      {'name': '09. Safe As Houses',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/TE02.jpg',
                      'video': 'https://archive.org/download/TheExo/S02E09.mp4',
                      'genre': 'Horror'},
                     {'name': '10. Unworthy',
                      'thumb': 'https://raw.githubusercontent.com/EmuZONE/YouTube/master/Images/TE02.jpg',
                      'video': 'https://archive.org/download/TheExo/S02E10.mp4',
                      'genre': 'Horror'}
                     ]}


def get_url(**kwargs):
    """
    Create a URL for calling the plugin recursively from the given set of keyword arguments.

    :param kwargs: "argument=value" pairs
    :type kwargs: dict
    :return: plugin call URL
    :rtype: str
    """
    return '{0}?{1}'.format(_url, urlencode(kwargs))


def get_categories():
    """
    Get the list of video categories.

    Here you can insert some parsing code that retrieves
    the list of video categories (e.g. 'Movies', 'TV-shows', 'Documentaries' etc.)
    from some site or server.

    .. note:: Consider using `generator functions <https://wiki.python.org/moin/Generators>`_
        instead of returning lists.

    :return: The list of video categories
    :rtype: types.GeneratorType
    """
    return VIDEOS.iterkeys()


def get_videos(category):
    """
    Get the list of videofiles/streams.

    Here you can insert some parsing code that retrieves
    the list of video streams in the given category from some site or server.

    .. note:: Consider using `generators functions <https://wiki.python.org/moin/Generators>`_
        instead of returning lists.

    :param category: Category name
    :type category: str
    :return: the list of videos in the category
    :rtype: list
    """
    return VIDEOS[category]


def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_handle, 'My Video Collection')
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_handle, 'videos')
    # Get video categories
    categories = get_categories()
    # Iterate through categories
    for category in categories:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=category)
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': VIDEOS[category][0]['thumb'],
                          'icon': VIDEOS[category][0]['thumb'],
                          'fanart': VIDEOS[category][0]['thumb']})
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # https://codedocs.xyz/xbmc/xbmc/group__python__xbmcgui__listitem.html#ga0b71166869bda87ad744942888fb5f14
        # 'mediatype' is needed for a skin to display info for this ListItem correctly.
        list_item.setInfo('video', {'title': category,
                                    'genre': category,
                                    'mediatype': 'video'})
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=listing&category=Animals
        url = get_url(action='listing', category=category)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def list_videos(category):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: Category name
    :type category: str
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_handle, category)
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_handle, 'videos')
    # Get the list of videos in the category.
    videos = get_videos(category)
    # Iterate through videos.
    for video in videos:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=video['name'])
        # Set additional info for the list item.
        # 'mediatype' is needed for skin to display info for this ListItem correctly.
        list_item.setInfo('video', {'title': video['name'],
                                    'genre': video['genre'],
                                    'mediatype': 'video'})
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
        # Set 'IsPlayable' property to 'true'.
        # This is mandatory for playable items!
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/wp-content/uploads/2017/04/crab.mp4
        url = get_url(action='play', video=video['video'])
        # Add the list item to a virtual Kodi folder.
        # is_folder = False means that this item won't open any sub-list.
        is_folder = False
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def play_video(path):
    """
    Play a video by the provided path.

    :param path: Fully-qualified video URL
    :type path: str
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            list_videos(params['category'])
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_video(params['video'])
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception. This helps to catch coding errors,
            # e.g. typos in action names.
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_categories()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])

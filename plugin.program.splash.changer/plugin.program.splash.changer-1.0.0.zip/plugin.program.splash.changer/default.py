#############################################################################
#############################################################################
import common
from common import *
from common import (addon_id,addon_name,addon_path)

#############################################################################
#############################################################################
ACTION_PREVIOUS_MENU 		=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_LEFT 				=   1	## Left arrow key
ACTION_MOVE_RIGHT 			=   2	## Right arrow key
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key
ACTION_MOUSE_CLICK_LEFT	= 101	## Mouse click left ??
ACTION_MOUSE_WHEEL_UP 	= 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN = 105	## Mouse wheel down
ACTION_MOUSE_DRAG 			= 106	## Mouse drag
ACTION_MOUSE_MOVE 			= 107	## Mouse move
#
ACTION_KEY_P						=	 79	## P - Pause
ACTION_KEY_R						=	 78	## R - Rewind
ACTION_KEY_F						=	 77	## F - Fast Forward
ACTION_SELECT_ITEM			=		7	## ?
ACTION_PARENT_DIR				=		9	## ?
ACTION_CONTEXT_MENU			=	117	## ?
ACTION_NEXT_ITEM				=	 14	## ?
ACTION_BACKSPACE				=	110	## ?
#
ACTION_KEY_X						=	 13	## X - Stop
ACTION_aID_0						=	  0	## ???
#
ACTION_REMOTE_MUTE					=	 91	## MUTE
#ACTION_REMOTE_FULLSCREEN		=	 ??	## FullScreen
ACTION_REMOTE_INFO					=	 11	## Info
ACTION_REMOTE_PLAYPAUSE			=	 12	## Play / Pause
ACTION_REMOTE_CONTEXTMENU		=	117	## Context Menu
ACTION_REMOTE_STOP					=	 13	## Stop
#
ACTION_KEY_VOL_MINUS				=	 89	## F - Fast Forward
ACTION_KEY_VOL_PLUS					=	 88	## F - Fast Forward
#
ACTION_SHOW_FULLSCREEN			=  36 ## Show Full Screen
ACTION_TOGGLE_FULLSCREEN		= 199 ## Toggle Full Screen
#############################################################################
#############################################################################

d=xbmcgui.Dialog(); 

class CustomWindow(xbmcgui.WindowXML):
#class CustomWindow(xbmcgui.WindowXMLDialog):
		closing=False; firsttime=False; c={}; strXMLname=''; strFallbackPath=''; List01D=[]; List01DB=[]
		maxW=1280; maxH=720; 
		##
		def __init__(self,strXMLname,strFallbackPath):
			self.strXMLname=strXMLname
			self.strFallbackPath=strFallbackPath
		def onInit(self):
			#try:
				try: self.wID=xbmcgui.getCurrentWindowId()
				except: self.wID=0
				deb('CurrentWindowId()',str(self.wID)); 
				deb('getResolution()',str(self.getResolution())); 
				self.firsttime=True
				debob(['screen size',self.getWidth(),self.getHeight()])
				debob(['skin size',self.maxW,self.maxH])
				self.LoadSkinItems()
				try: self.setFocus(self.bExit)
				except: pass
				self.setupScreen()
				try: self.setFocus(self.BtnTopMenu01)
				except: pass
			#except: pass
		def loadBGGraphic(self,SplashFile=''):
			try:
				if len(SplashFile)==0:
					self.SplashFileR=''
					self.SplashFileH=os.path.join(tP('special://home'),'media','Splash.png')
					self.SplashFileI=os.path.join(tP('special://xbmc'),'media','Splash.png')
					if isFile(self.SplashFileH): SplashFile=self.SplashFileH
					elif isFile(self.SplashFileI): SplashFile=self.SplashFileI
					else: SplashFile=MediaFile("black1.png"); 
				try: self.iBackground.setImage(SplashFile,False); 
				except: self.iBackground.setImage(SplashFile); 
			except:
				self.iBackground.setImage(MediaFile("black1.png")); 
		def setupScreen(self):
			try:
				#self.iBack.setImage(artp("black1")); 
				#self.iBackground.setImage(MediaFile("black1.png")); 
				self.iBack.setImage(MediaFile("black1.png")); 
				self.loadBGGraphic()
				##
			except: pass
		def LoadSkinItems(self):
			try:
				self.c['iBack']=1; 
				self.c['iBackground']=2; 
				self.c['bExit']=10; 
				try: self.iBack=self.getControl(self.c['iBack']); 
				except: pass
				try: self.iBackground=self.getControl(self.c['iBackground']); 
				except: pass
				try: self.bExit=self.getControl(self.c['bExit']); 
				except: pass
				
				self.c['ErrLabel02']=101; 
				try: self.ErrLabel02=self.getControl(self.c['ErrLabel02']); 
				except: pass
				self.c['BtnTopMenu01']=400; 
				try: self.BtnTopMenu01=self.getControl(self.c['BtnTopMenu01']); 
				except: pass
				self.c['BtnTopMenu02']=401; 
				try: self.BtnTopMenu02=self.getControl(self.c['BtnTopMenu02']); 
				except: pass
				self.c['BtnTopMenu03']=402; 
				try: self.BtnTopMenu03=self.getControl(self.c['BtnTopMenu03']); 
				except: pass
				self.c['BtnTopMenu04']=403; 
				try: self.BtnTopMenu04=self.getControl(self.c['BtnTopMenu04']); 
				except: pass
				self.c['BtnTopMenu05']=404; 
				try: self.BtnTopMenu05=self.getControl(self.c['BtnTopMenu05']); 
				except: pass
				
				
				
				
			except: pass
		def ScrTp(self,s='',v='ScreenType'):
			try:
				if len(v) > 0:
					self.setProperty(v,s); 
			except: pass
		def onClick(self,controlId):
			#try:
				if   controlId==self.c['bExit']: self.AskToClose()
				elif   controlId==self.c['BtnTopMenu01']: ## Add ##
					try:
						u=showkeyboard("","Please give the url of an image:")
						debob({'u':u}); 
						if len(u) > 0: 
							self.SplashFileR=u
							self.loadBGGraphic(u)
					except: pass
				elif   controlId==self.c['BtnTopMenu02']: ## Remove ##
					try:
						u=popBrowseImage("Please browse for an image:")
						debob({'u':u}); 
						if len(u) > 0: 
							self.SplashFileR=u
							self.loadBGGraphic(u)
						pass
					except: pass
				elif   controlId==self.c['BtnTopMenu03']: ## Clear ##
					try:
						self.SplashFileR=''
						self.loadBGGraphic('')
						pass
					except: pass
				elif   controlId==self.c['BtnTopMenu04']: ## Save ##
					try:
						u=self.SplashFileR
						if len(u) > 0:
							if u.lower().startswith('special://'): u=tP(u)
							elif (u.lower().startswith('http://')) or (u.lower().startswith('https://')) or (u.lower().startswith('ftp://')):
								try:
									import HiddenDownloader
									HiddenDownloader.download(u,'Splash.png',os.path.join(tP('special://home'),'media'),useResolver=False)
								except: pass
							else:
								try:
									shutil.copyfile(u,self.SplashFileH)
								except: pass
						#xbmc.sleep(2000)
						self.SplashFileR=''
						self.loadBGGraphic('')
						pass
					except:
						self.SplashFileR=''
						self.loadBGGraphic('')
				elif   controlId==self.c['BtnTopMenu05']: ## Default ##
					try:
						self.SplashFileR=''
						
						try:
							if isFile(self.SplashFileH):
								try:
									os.remove(self.SplashFileH)
								except: pass
						except: pass
						
						self.loadBGGraphic('')
						pass
					except: pass
				else:
					try:
						
						pass
					except: pass
			#except Exception,e: debob(["Error",e])
			#except: pass
		def onAction(self,action): 
			try:
				actId=int(action.getId()); actIds=str(action.getId()); actBC=str(action.getButtonCode()); xx=0; yy=0; 
				try: actAmnt1=action.getAmount1()
				except: actAmnt1=0-900
				try: actAmnt2=action.getAmount2()
				except: actAmnt2=0-900
				mW=self.maxW; mH=self.maxH; mWa=int(self.getWidth()); mHa=int(self.getHeight()); 
				actAmnt1k=int(actAmnt1*mW/mWa); actAmnt2k=int(actAmnt2*mH/mHa); 
				##
				if   action==ACTION_PREVIOUS_MENU: self.AskToClose()
				elif action==ACTION_NAV_BACK: self.AskToClose()
				else:
					if not actId==0:
						#debob({'action type':'UNKNOWN','getId':actId,'getButtonCode':actBC,'getAmount1':actAmnt1,'getAmount2':actAmnt2})
						pass
						##
					##
				##
			except Exception,e: debob(["Error",e]); debob([actId,actIds,actBC])
			except: pass
		def CloseWindow(self):
			try:
				self.closing=True; 
			except: pass
			self.close()
		def CW(self): self.CloseWindow()
		def AskToClose(self):
			try:
				if self.closing==False:
					if d.yesno(addonName," ","Are you sure that you want to exit?","","No","Yes"): self.closing=True; self.CloseWindow()
				else: self.CloseWindow()
			except: pass
		##
######


#############################################################################
#############################################################################
skinFilename='CustomWindow001.xml'
try:    Emulating=xbmcgui.Emulating
except: Emulating=False
if __name__=='__main__':
	#cWind=CustomWindow(skinFilename,addon_path,'default')
	cWind=CustomWindow(skinFilename,addon_path) #,'default'
	cWind.doModal()
	del cWind
	sys.modules.clear()

#############################################################################
#############################################################################

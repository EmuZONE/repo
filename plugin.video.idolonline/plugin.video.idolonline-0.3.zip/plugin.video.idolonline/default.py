import util
import aidoruonline as ao
import realdebrid as rd
import menu
import json, ast, urllib, os
import xbmcaddon
try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database

ADDON_ID='plugin.video.idolonline'
addon = xbmcaddon.Addon(id=ADDON_ID)
profileDir = addon.getAddonInfo('profile')
profileDir = xbmc.translatePath(profileDir).decode("utf-8")
home=xbmc.translatePath(addon.getAddonInfo('path').decode('utf-8'))

if not os.path.exists(profileDir):
    os.makedirs(profileDir)

libraryDir=xbmc.translatePath(xbmcaddon.Addon().getSetting('library_path'))
if not os.path.exists(libraryDir):
    os.makedirs(libraryDir)    

dbFile = os.path.join(profileDir, 'files.db')  
dbcon=database.connect(dbFile)
dbcur=dbcon.cursor()
try:
    dbcur.execute("CREATE TABLE IF NOT EXISTS rd (id INTEGER PRIMARY KEY, rd_id STRING);")
except:
    pass
    
parameters=util.parseParameters()
try:
    mode=int(parameters["mode"])
except:
    mode=None

# check to see if realdebrid has been setup, if not we dont want to go any further
if rd.checkDetails():
    if xbmcaddon.Addon().getSetting('username')=="" or xbmcaddon.Addon().getSetting('password')=="":
        util.alert("You must enter your Aidoru Online account details")
        xbmcaddon.Addon(id='plugin.video.idolonline').openSettings()
    elif mode==1:
        ao_opener=ao.login(xbmcaddon.Addon().getSetting('username'), xbmcaddon.Addon().getSetting('password'))
        
        extras=ast.literal_eval(parameters['extras'])
        
        if "page" in extras:
            extras['page']=str(int(extras['page'])+1)
        else:
            extras={}
            extras['page']="0"
        
        if "searchstr" in extras:
            details=ao.getTorrents(p=extras['page'], searchstr=extras['searchstr'])
        else:
            details=ao.getTorrents(p=extras['page'])
        
        items=[]
        for detail in details:
            items.append({
                "title": detail['name'].decode('utf-8'),
                "url": urllib.quote_plus(detail['torrent']), 
                "mode":2, 
                "poster":"",
                "icon":os.path.join(home, '', 'icon.png'),
                "fanart":os.path.join(home, '', 'fanart.jpg'),
                "type":"video", 
                "plot": "",
                "isFolder":False
            })
        items.append({
            "title": "Next >",
            "url": "", 
            "mode":1, 
            "poster":"",
            "icon":"", 
            "fanart":"",
            "type":"video", 
            "plot": "",
            "isFolder": True,
            "extras": extras
        })
        util.addMenuItems(items)
    elif mode==2:
        xbmc.executebuiltin( "ActivateWindow(busydialog)" )
        ao_opener=ao.login("ptom", "m0rn1ngm")
        torrent=parameters['url']
        file=torrent.replace("https://aidoru-online.org/download.php?id=", "")+".torrent"
        file=ao.downloadTorrent(torrent, file)
        newParameters={"torrent_file":file}
        id=str(rd.addTorrent(newParameters))
        xbmc.executebuiltin( "Dialog.Close(busydialog)" )
        if "False" not in id:
            dbcon=database.connect(dbFile)
            dbcur=dbcon.cursor()
            dbcur.execute("INSERT INTO rd (rd_id) VALUES (?)", (id,))
            dbcon.commit()
            dbcon.close()
            util.notify(ADDON_ID, "File successfully added")
    elif mode==3:
        dbcon=database.connect(dbFile)
        dbcur=dbcon.cursor()
        dbcur.execute("SELECT id, rd_id FROM rd ORDER BY id DESC")
        data=dbcur.fetchall()
        if data:
            menu=[]
            for id in data:
                util.logError(id[1] )
                if "False" not in id[1]:
                    item=rd.torrentsInfo(id[1])
                    if item:
                        #util.logError(str(file))
                        #links=json.loads(file)
                        #util.logError(str(links))
                        
                        if item['status'] == "downloaded":
                            #util.logError(str(torrentsInfo(item['id'])))
                            name=item['filename']
                            url=item['links'][0]
                            mode=5
                        elif item['status']== "downloading":
                            name="[Downloading "+str(item['progress'])+"%] "+item['filename']
                            url=""
                            mode=""
                        else:
                            name="["+item['status']+"] "+item['filename']
                            url=""
                            mode=""
                        menu.append({
                            "title": name,
                            "url": url,
                            "mode": mode, 
                            "poster":"",
                            "icon":os.path.join(home, '', 'icon.png'),
                            "fanart":os.path.join(home, '', 'fanart.jpg'),
                            "type":"video", 
                            "plot":item['host'],
                            "method":"torrent",
                            "id":item['id'],
                            "isFolder":False,
                            "playable":False,
                            "download":True
                        })
            util.addMenuItems(menu)
    elif mode==4:
        search=util.searchDialog()
        ao_opener=ao.login("ptom", "m0rn1ngm")
        
        extras=ast.literal_eval(parameters['extras'])
        
        if "page" in extras:
            page=str(extras['page'])
        else:
            page=str(0)
        
        details=ao.getTorrents(searchstr=search, p=page)
        
        items=[]
        for detail in details:
            items.append({
                "title": detail['name'].decode('utf-8'),
                "url": urllib.quote_plus(detail['torrent']), 
                "mode":2, 
                "poster":"",
                "icon":os.path.join(home, '', 'icon.png'),
                "fanart":os.path.join(home, '', 'fanart.jpg'),
                "type":"video", 
                "plot": "",
                "isFolder":False
            })
        items.append({
            "title": "Next >",
            "url": "", 
            "mode":1, 
            "poster":"",
            "icon":"", 
            "fanart":"",
            "type":"video", 
            "plot": "",
            "isFolder": True,
            "extras": {"searchstr":str(search), "page":str(int(page)+1)}
        })
        util.addMenuItems(items)
        
    elif mode==5:
        link=rd.unrestrict(parameters)
        if link==False:
            util.alert("Unable to unrestrict link")
        else:
            if link['streamable']==1:
                util.playMedia(link['filename'], link['host_icon'], link['download'], force=True)
            else:
                util.logError(str(link))
    elif mode==12:
        rd.download(parameters, libraryDir)
    elif mode==13:
        rd.delID(parameters)
    else:
        util.addMenuItems(menu.mainMenu)
        
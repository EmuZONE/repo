#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon,sys,os,zipfile
from sqlite3 import dbapi2 as db_lib

def en_de_code_path(path):
    if sys.platform.startswith('win'):
        return os.path.normpath(os.path.abspath(path)).decode('utf-8')
    else:
        return os.path.normpath(os.path.abspath(path)).encode('utf-8')

_addon_ = xbmcaddon.Addon()
_addon_id_ = _addon_.getAddonInfo('id')

zip_file_path_settings = _addon_.getSetting('zip_file_path')
if not zip_file_path_settings:
    xbmc.executebuiltin('Addon.OpenSettings('+ _addon_id_ +')')
    sys.exit(0)

_sys_build_version_ = xbmc.getInfoLabel('System.BuildVersion')
_backup_file_path_ = en_de_code_path(xbmc.translatePath(zip_file_path_settings))
_home_path_ = en_de_code_path(xbmc.translatePath('special://home/'))
_database_path_ = en_de_code_path(xbmc.translatePath('special://profile/Database'))

def delete_file(file):
    if os.path.exists(file):
        try:
            os.remove(file)
        except:
            pass

def clean_data(home_path,addon,addon_id):
    dp = xbmcgui.DialogProgress()
    dp.create('CLEAN DATA','Bereinige Daten !','Bitte warten ...')
    dp.update(0)
    filesList = []
    save_list_array = []
    try:
        skin_id = xbmc.getSkinDir()
        if not addon_id == '':
            save_list_array.append(addon_id)
        if not skin_id == '':
            save_list_array.append(skin_id)
        if addon.getSetting('save_old_favourites') == 'true':
            save_list_array.append('favourites.xml')
        save_list_array.append('Addons26.db')
        save_list_array.append('Addons27.db')
        save_list_array.append('Textures13.db')
        save_list_array.append('commoncache.db')
        save_list_array.append('metadata.album.universal')
        save_list_array.append('metadata.artists.universal')
        save_list_array.append('metadata.common.musicbrainz.org')
        save_list_array.append('metadata.common.imdb.com')
        filesList = list(os.walk(home_path,topdown=False,onerror=None,followlinks=True))
        count = int(0)
        filesCount = float(0)
        filesCount += float(len(filesList))
        for pathentry in filesList:
            for dir in pathentry[1]:
                path = os.path.join(pathentry[0],dir)
                if not any((x in path for x in save_list_array)):
                    if os.path.islink(path):
                        try:
                            os.unlink(path)
                        except:
                            pass
                    else:
                        try:
                            os.rmdir(path)
                        except:
                            pass
            for file in pathentry[2]:
                path = os.path.join(pathentry[0],file)
                if not any((x in path for x in save_list_array)):
                    try:
                        os.unlink(path)
                    except:
                        pass
            count += 1
            update = count / filesCount * 100
            dp.update(int(update))
            if dp.iscanceled():
                dp.close()
                sys.exit(0)
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok('ERROR !', str(e))
        sys.exit(0)
    dp.close()
	
def check_zipfile(zip_file_full_path):
    if os.path.exists(zip_file_full_path):
        try:
           return zipfile.ZipFile(zip_file_full_path,mode='r',compression=zipfile.ZIP_STORED,allowZip64=True)
        except zipfile.BadZipfile:
            return 'No zip file !'
    else:
        return 'No zip file !'

def extract_zip(zipfile,zip_file_full_path,home_path,addon,addon_id,zip_pwd=None):
    if not os.path.exists(zip_file_full_path):
        xbmcgui.Dialog().ok('ZIP EXTRACT ERROR !','File not found !')
        sys.exit(0) 
    dp = xbmcgui.DialogProgress()
    dp.create('BACKUP EXTRACTOR','Entpacke Daten !','Bitte warten ...')
    dp.update(0)
    count = int(0)
    try:
        nFiles = float(len(zipfile.infolist()))
        for item in zipfile.infolist():
            count += 1
            update = count / nFiles * 100
            dp.update(int(update))
            try:
                if addon.getSetting('save_old_favourites') == 'true':
                    if addon_id not in item.filename and not 'favourites.xml' in item.filename:
                        zipfile.extract(item,path=home_path,pwd=zip_pwd)
                else:
                    if addon_id not in item.filename:
                        zipfile.extract(item,path=home_path,pwd=zip_pwd)
            except:
                pass
            if dp.iscanceled():
                dp.close()
                sys.exit(0)
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok('ZIP EXTRACT ERROR !',str(e))
        sys.exit(0)
    dp.close()
    zipfile.close()
	
def wizard_activator(database_path,home_path,sys_build_version,addon_id):
    if float(sys_build_version[0:4]) >= 17.0:
        conn = db_lib.connect(os.path.join(database_path,'Addons27.db'))
        conn.text_factory = str
        conn.executemany('update installed set enabled=1 WHERE addonID = (?)',addon_id)
        conn.commit()

def get_platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    if xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    if xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    if xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    if xbmc.getCondVisibility('system.platform.atv'):
        return 'atv2'
    if xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    if xbmc.getCondVisibility('system.platform.atv3'):
        return 'atv3'
    if xbmc.getCondVisibility('system.platform.atv4'):
        return 'atv4'
    if xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

def killxbmc():
    myplatform = get_platform()
    i = xbmcgui.Dialog().yesno('KODI BEENDEN', 'Sie sind dabei Kodi zu schlie\xc3\x9fen !', 'M\xc3\xb6chten Sie fortfahren ?', nolabel='NEIN', yeslabel='JA')
    if i < 1:
        sys.exit(0)
    if myplatform == 'osx':
        try:
            os.system('killall -9 Kodi')
        except:
            pass
        xbmcgui.Dialog().ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !' + '\n\n' + 'Schlie\xc3\x9fen Sie Kodi \xc3\xbcber den [COLOR red]Taskmanager[/COLOR] oder' + '\n' + 'starten Sie das Ger\xc3\xa4t manuell neu !' + '\n\n' + '[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
    elif myplatform == 'linux':
        try:
            os.system('killall Kodi')
        except:
            pass
        try:
            os.system('killall -9 kodi.bin')
        except:
            pass
        xbmcgui.Dialog().ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !' + '\n\n' + 'Schlie\xc3\x9fen Sie Kodi \xc3\xbcber den [COLOR red]Taskmanager[/COLOR] oder' + '\n' + 'starten Sie das Ger\xc3\xa4t manuell neu !' + '\n\n' + '[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
    elif myplatform == 'android':
        try:
            os.system('adb shell am force-stop org.xbmc.kodi')
        except:
            pass
        try:
            os.system('adb shell am kill org.xbmc.kodi')
        except:
            pass
        try:
            os.system('Process.killProcess(android.os.Process.org.xbmc.kodi());')
        except:
            pass
        try:
            os.system('adb shell am force-stop com.semperpax.spmc16')
        except:
            pass
        try:
            os.system('adb shell am kill com.semperpax.spmc16')
        except:
            pass
        try:
            os.system('Process.killProcess(android.os.Process.com.semperpax.spmc16());')
        except:
            pass
        try:
            os.system('adb shell am force-stop com.semperpax.spmc17')
        except:
            pass
        try:
            os.system('adb shell am kill com.semperpax.spmc17')
        except:
            pass
        try:
            os.system('Process.killProcess(android.os.Process.com.semperpax.spmc17());')
        except:
            pass
        xbmcgui.Dialog().ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !' + '\n\n' + 'Schlie\xc3\x9fen Sie Kodi \xc3\xbcber den [COLOR red]Taskmanager[/COLOR] oder' + '\n' + 'starten Sie das Ger\xc3\xa4t manuell neu !' + '\n\n' + '[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
        xbmc.executebuiltin('StartAndroidActivity("","android.settings.APPLICATION_SETTINGS","","")')
    elif myplatform == 'windows':
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except:
            pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except:
            pass
        xbmcgui.Dialog().ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !' + '\n\n' + 'Schlie\xc3\x9fen Sie Kodi \xc3\xbcber den [COLOR red]Taskmanager[/COLOR] oder' + '\n' + 'starten Sie das Ger\xc3\xa4t manuell neu !' + '\n\n' + '[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
    else:
        try:
            os.system('killall AppleTV')
        except:
            pass
        try:
            os.system('sudo initctl stop kodi')
        except:
            pass
        xbmcgui.Dialog().ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !' + '\n\n' + 'Schlie\xc3\x9fen Sie Kodi \xc3\xbcber den [COLOR red]Taskmanager[/COLOR] oder' + '\n' + 'starten Sie das Ger\xc3\xa4t manuell neu !' + '\n\n' + '[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
    sys.exit(0)
	
def run():
    _zip_file_ = check_zipfile(_backup_file_path_)

    if _zip_file_ == 'No zip file !':
        delete_file(_backup_file_path_)
        xbmcgui.Dialog().ok('ZIP FILE ERROR !',_zip_file_)
        sys.exit(0)

    if _addon_.getSetting('auto_clean_on_off') == 'true':
        clean_data(_home_path_,_addon_,_addon_id_)
        xbmc.sleep(2000)

    extract_zip(_zip_file_,_backup_file_path_,_home_path_,_addon_,_addon_id_)
    xbmc.sleep(2000)

    wizard_activator(_database_path_,_home_path_,_sys_build_version_,_addon_id_)
    xbmc.sleep(2000)
    killxbmc()
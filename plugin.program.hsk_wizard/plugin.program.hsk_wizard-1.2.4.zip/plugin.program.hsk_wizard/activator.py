#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,os,sys
from sqlite3 import dbapi2 as db_lib

def en_de_code_path(path):
    if sys.platform.startswith('win'):
        return os.path.normpath(os.path.abspath(path)).decode('utf-8')
    else:
        return os.path.normpath(os.path.abspath(path)).encode('utf-8')

def get_version():
    return float(xbmc.getInfoLabel('System.BuildVersion')[0:4])

def check_updates():
    xbmc.executebuiltin('XBMC.UpdateLocalAddons()')
    xbmc.executebuiltin('XBMC.UpdateAddonRepos()')

def set_all_enable():
    if get_version() >= 17.0:
        conn = db_lib.connect(os.path.join(en_de_code_path(xbmc.translatePath('special://profile/Database')),'Addons27.db'))
        conn.text_factory = str
        conn.executemany('update installed set enabled=1 WHERE addonID = (?)', ((val,) for val in os.listdir(os.path.join(en_de_code_path(xbmc.translatePath('special://home')),'addons'))))
        conn.commit()

def run():
    dp = xbmcgui.DialogProgress()
    dp.create('ADDONS ACTIVATOR', 'Aktiviere Addons !', 'Bitte warten...')
    dp.update(0)
    check_updates()
    xbmc.sleep(500)
    dp.update(10)
    xbmc.sleep(500)
    dp.update(20)
    xbmc.sleep(500)
    dp.update(30)
    set_all_enable()
    xbmc.sleep(500)
    dp.update(40)
    xbmc.sleep(500)
    dp.update(50)
    xbmc.sleep(500)
    dp.update(60)
    check_updates()
    xbmc.sleep(500)
    dp.update(70)
    xbmc.sleep(500)
    dp.update(80)
    xbmc.sleep(500)
    dp.update(90)
    xbmc.sleep(500)
    dp.update(100)
    dp.close()
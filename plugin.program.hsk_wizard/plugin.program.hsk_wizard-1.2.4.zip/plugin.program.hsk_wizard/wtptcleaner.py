#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon,os,sys,math

def en_de_code_path(path):
    if sys.platform.startswith('win'):
        return os.path.normpath(os.path.abspath(path)).decode('utf-8')
    else:
        return os.path.normpath(os.path.abspath(path)).encode('utf-8')

_addon_ = xbmcaddon.Addon()
_addon_path_ = en_de_code_path(xbmc.translatePath(_addon_.getAddonInfo('path')))

_temp_path_       = en_de_code_path(xbmc.translatePath('special://temp'))
_packages_path_   = en_de_code_path(xbmc.translatePath('special://home/addons/packages'))
_thumbnails_path_ = en_de_code_path(xbmc.translatePath('special://thumbnails'))
_addon_data_path_ = os.path.join(_addon_path_,'resources','data')

def get_convert_size(size):
	if (size == 0):
		return '0B'
	units = (' B', ' KB', ' MB', ' GB', ' TB', ' PB', ' EB', ' ZB', ' YB')
	i = int(math.floor(math.log(size,1024)))
	p = math.pow(1024,i)
	size = round(size/p,2)
	return '{}{}'.format(size,units[i])

def get_directory_size(dir_path):
    size = 0
    for (path, dirs, files) in os.walk(dir_path,topdown=False,onerror=None,followlinks=True):
        for file in files:
            full_file_path = os.path.join(path, file)
            size += int(os.path.getsize(full_file_path))
    return int(size)
	
def clean_dir(dir_path,clear_info):
    if os.path.exists(dir_path):
        dp = xbmcgui.DialogProgress()
        dp.create('CLEAN DATA',clear_info,'Bitte warten ...')
        dp.update(0)
        xbmc.sleep(1000)
        filesList = []
        try:
            filesList = list(os.walk(dir_path,topdown=False,onerror=None,followlinks=True))
            count = int(0)
            filesCount = float(0)
            filesCount += float(len(filesList))
            for pathentry in filesList:
                for dir in pathentry[1]:
                    path = os.path.join(pathentry[0],dir)
                    if os.path.islink(path):
                        try:
                            os.unlink(path)
                        except:
                            pass
                    else:
                        try:
                            os.rmdir(path)
                        except:
                            pass
                for file in pathentry[2]:
                    path = os.path.join(pathentry[0],file)
                    try:
                        os.unlink(path)
                    except:
                        pass		
                count += 1
                update = count / filesCount * 100
                dp.update(int(update))
                if dp.iscanceled():
                    dp.close()
        except Exception as e:
            dp.close()
            xbmcgui.Dialog().ok('ERROR !', str(e))
            sys.exit(0)
        dp.close()
        xbmc.sleep(1000)

def clean_data_info():	 
    i = xbmcgui.Dialog().yesno('WTPT CLEANER','Wizard = ' + str(get_convert_size(get_directory_size(_addon_data_path_))),'Temp       = ' + str(get_convert_size(get_directory_size(_temp_path_))),'Packages = ' + str(get_convert_size(get_directory_size(_packages_path_))),'Exit','Clean')

    if i == 0:
         sys.exit(0)
    if os.path.exists(_addon_data_path_):
        clean_dir(_addon_data_path_,'Bereinige Wizard !')
    if os.path.exists(_temp_path_ ):
        clean_dir(_temp_path_,'Bereinige Temp !')  
    if os.path.exists(_packages_path_ ):
        clean_dir(_packages_path_,'Bereinige Packages !')

    xbmcgui.Dialog().ok('WTPT CLEANER','Wizard = ' + str(get_convert_size(get_directory_size(_addon_data_path_))),'Temp       = ' + str(get_convert_size(get_directory_size(_temp_path_))),'Packages = ' + str(get_convert_size(get_directory_size(_packages_path_))))
	
    if xbmcgui.Dialog().yesno('CLEAN THUMBNAILS','Nach dieser Option, muss Kodi neu gestartet werden !','','','Exit','Clean') == 1:
        if os.path.exists(_thumbnails_path_ ):
            clean_dir(_thumbnails_path_,'Bereinige Thumbnails !')
            return True

def get_platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    if xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    if xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    if xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    if xbmc.getCondVisibility('system.platform.atv'):
        return 'atv2'
    if xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    if xbmc.getCondVisibility('system.platform.atv3'):
        return 'atv3'
    if xbmc.getCondVisibility('system.platform.atv4'):
        return 'atv4'
    if xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

def killxbmc():
    myplatform = get_platform()
    i = xbmcgui.Dialog().yesno('KODI BEENDEN', 'Sie sind dabei Kodi zu schlie\xc3\x9fen !', 'M\xc3\xb6chten Sie fortfahren ?', nolabel='NEIN', yeslabel='JA')
    if i < 1:
        sys.exit(0)
    if myplatform == 'osx':
        try:
            os.system('killall -9 Kodi')
        except:
            pass
        xbmcgui.Dialog().ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !' + '\n\n' + 'Schlie\xc3\x9fen Sie Kodi \xc3\xbcber den [COLOR red]Taskmanager[/COLOR] oder' + '\n' + 'starten Sie das Ger\xc3\xa4t manuell neu !' + '\n\n' + '[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
    elif myplatform == 'linux':
        try:
            os.system('killall Kodi')
        except:
            pass
        try:
            os.system('killall -9 kodi.bin')
        except:
            pass
        xbmcgui.Dialog().ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !' + '\n\n' + 'Schlie\xc3\x9fen Sie Kodi \xc3\xbcber den [COLOR red]Taskmanager[/COLOR] oder' + '\n' + 'starten Sie das Ger\xc3\xa4t manuell neu !' + '\n\n' + '[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
    elif myplatform == 'android':
        try:
            os.system('adb shell am force-stop org.xbmc.kodi')
        except:
            pass
        try:
            os.system('adb shell am kill org.xbmc.kodi')
        except:
            pass
        try:
            os.system('Process.killProcess(android.os.Process.org.xbmc.kodi());')
        except:
            pass
        try:
            os.system('adb shell am force-stop com.semperpax.spmc16')
        except:
            pass
        try:
            os.system('adb shell am kill com.semperpax.spmc16')
        except:
            pass
        try:
            os.system('Process.killProcess(android.os.Process.com.semperpax.spmc16());')
        except:
            pass
        try:
            os.system('adb shell am force-stop com.semperpax.spmc17')
        except:
            pass
        try:
            os.system('adb shell am kill com.semperpax.spmc17')
        except:
            pass
        try:
            os.system('Process.killProcess(android.os.Process.com.semperpax.spmc17());')
        except:
            pass
        xbmcgui.Dialog().ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !' + '\n\n' + 'Schlie\xc3\x9fen Sie Kodi \xc3\xbcber den [COLOR red]Taskmanager[/COLOR] oder' + '\n' + 'starten Sie das Ger\xc3\xa4t manuell neu !' + '\n\n' + '[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
        xbmc.executebuiltin('StartAndroidActivity("","android.settings.APPLICATION_SETTINGS","","")')
    elif myplatform == 'windows':
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except:
            pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except:
            pass
        xbmcgui.Dialog().ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !' + '\n\n' + 'Schlie\xc3\x9fen Sie Kodi \xc3\xbcber den [COLOR red]Taskmanager[/COLOR] oder' + '\n' + 'starten Sie das Ger\xc3\xa4t manuell neu !' + '\n\n' + '[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
    else:
        try:
            os.system('killall AppleTV')
        except:
            pass
        try:
            os.system('sudo initctl stop kodi')
        except:
            pass
        xbmcgui.Dialog().ok('[COLOR red]ACHTUNG ![/COLOR]', 'Kodi konnte nicht beendet werden !' + '\n\n' + 'Schlie\xc3\x9fen Sie Kodi \xc3\xbcber den [COLOR red]Taskmanager[/COLOR] oder' + '\n' + 'starten Sie das Ger\xc3\xa4t manuell neu !' + '\n\n' + '[COLOR red]Verwenden Sie nicht die Kodi Quit / Exit Optionen ![/COLOR]')
    sys.exit(0)

def run():
    if clean_data_info() == True :
        xbmc.sleep(2000)
        killxbmc()
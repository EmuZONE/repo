#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,urllib,urllib2,socket,os,sys,re

def en_de_code_path(path):
    if sys.platform.startswith('win'):
        return os.path.normpath(os.path.abspath(path)).decode('utf-8')
    else:
        return os.path.normpath(os.path.abspath(path)).encode('utf-8')

addons_path = os.path.join(en_de_code_path(xbmc.translatePath('special://home')), 'addons')

def run():
    repository_path_array = []
    for dirname in os.listdir(addons_path):
        if os.path.isdir(os.path.join(addons_path, dirname)) and 'repository' in str(dirname):
            repository_path_array.append(os.path.join(addons_path, dirname))

    filesCount = float(0)
    filesCount += float(len(repository_path_array))
    count = 0
    dp = xbmcgui.DialogProgress()
    dp.create('REPO CHECKER','Repo Status Test !','Bitte warten ...')
    update = int(0)
    dp.update(update)
    xbmc.sleep(2000)
    output = ''

    http_code_array = ['100 Weiter',
     '101 Umschalten von Protokollen',
     '102 Verarbeitung',
     '200 OK',
     '201 Erstellt',
     '202 akzeptiert',
     '203 Nicht-ma\xc3\x9fgebliche Informationen',
     '204 Kein Inhalt',
     '205 Inhalt zur\xc3\xbccksetzen',
     '206 Teilinhalt',
     '207 Multi-Status',
     '208 Bereits berichtet',
     '226 IM verwendet',
     '300 Mehrfachauswahl',
     '301 dauerhaft verschoben',
     '302 Gefunden',
     '303 Siehe andere',
     '304 nicht modifiziert',
     '305 Proxy verwenden',
     '307 Vor\xc3\xbcbergehende Weiterleitung',
     '308 Permanent Redirect',
     '400 schlechte Anfrage',
     '401 Unerlaubt',
     '402 Zahlung erforderlich',
     '403 verboten',
     '404 nicht gefunden',
     '405 Methode nicht erlaubt',
     '406 nicht akzeptabel',
     '407 Proxy-Authentifizierung erforderlich',
     '408 Zeitplan anfordern',
     '409 Konflikt',
     '410 gegangen',
     '411 L\xc3\xa4nge erforderlich',
     '412 Voraussetzung fehlgeschlagen',
     '413 Nutzlast zu gro\xc3\x9f',
     '414 Request-URI zu lang',
     '415 Nicht unterst\xc3\xbctzter Medientyp',
     '416 Angeforderte Reichweite nicht befriedigend',
     '417 Erwartung fehlgeschlagen',
     '418 Ich bin eine Teekanne',
     '421 Misdirected Anfrage',
     '422 Unprocessable Entity',
     '423 Gesperrt',
     '424 fehlgeschlagene Abh\xc3\xa4ngigkeit',
     '426 Upgrade erforderlich',
     '428 Voraussetzung erforderlich',
     '429 Zu viele Anfragen',
     '431 Anforderungsheaderfelder zu gro\xc3\x9f',
     '444 Verbindung ohne Reaktion geschlossen',
     '451 Aus rechtlichen Gr\xc3\xbcnden nicht verf\xc3\xbcgbar',
     '499 Client Geschlossene Anfrage',
     '500 Interner Serverfehler',
     '501 nicht implementiert',
     '502 Bad Gateway',
     '503 Service nicht verf\xc3\xbcgbar',
     '504 Gateway Zeit\xc3\xbcberschreitung',
     '505 HTTP-Version wird nicht unterst\xc3\xbctzt',
     '506 Variante auch verhandelt',
     '507 Unzureichende Lagerung',
     '508 Loop erkannt',
     '510 nicht verl\xc3\xa4ngert',
     '511 Netzwerk-Authentifizierung erforderlich',
     '599 Network Connect Timeout Fehler']

    for repository_path in repository_path_array:
        xml_path = os.path.join(repository_path, 'addon.xml')
        xml_content = open(xml_path).read()
        for name, url in re.findall('<addon[^<>]*>[\\s\\S].*?name="(.*?)">*?[^<>]*>[\\s\\S]*?<info[^<>].*?>(.*?)<\\/info>', xml_content, re.DOTALL):
            try:
                socket.setdefaulttimeout(30)
                req= urllib2.Request(url)
                resp = urllib2.urlopen(req,timeout=30)
                status_code = str(resp.getcode())
                resp.close()
                if any((status_code in s for s in http_code_array)):
                    for http_code in http_code_array:
                        if status_code in http_code:
                            dp.update(update, 'Teste Repo :', urllib.unquote_plus(name), urllib.unquote_plus(http_code))
                            output += urllib.unquote_plus(name) + ' = ' + urllib.unquote_plus(http_code) + '\n'
                else:
                    dp.update(update, 'Teste Repo :', urllib.unquote_plus(name),'[COLOR red]Unbekannter Statuscode[/COLOR]')
                    output += urllib.unquote_plus(name) + ' = ' + '[COLOR red]Unbekannter Statuscode[/COLOR]' + '\n'

            except Exception as e:
                resp.close()
                dp.update(update, 'Teste Repo :', urllib.unquote_plus(name),'[COLOR red]' +str(e)+ '[/COLOR]')
                output += urllib.unquote_plus(name) + ' = ' + '[COLOR red]' +str(e)+ '[/COLOR]' + '\n'

        count += 1
        update = int(count / filesCount * 100)
        dp.update(update)
        if dp.iscanceled():
            resp.close()
            dp.close()
            sys.exit(0)

    xbmc.sleep(2000)
    dp.close()
    xbmc.sleep(2000)
    if not output: output = 'Keine Repos gefunden !'
    xbmcgui.Dialog().textviewer('REPO TESTER',output)
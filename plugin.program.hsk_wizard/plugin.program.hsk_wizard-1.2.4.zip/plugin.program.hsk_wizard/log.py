#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,os,sys

def en_de_code_path(path):
    if sys.platform.startswith('win'):
        return os.path.normpath(os.path.abspath(path)).decode('utf-8')
    else:
        return os.path.normpath(os.path.abspath(path)).encode('utf-8')

def get_python_version():
    return str(sys.version)[0:6].strip()

def get_build_version():
	return str(xbmc.getInfoLabel('System.BuildVersion'))[0:5].strip()

def get_platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'Android'
    if xbmc.getCondVisibility('system.platform.linux'):
        return 'Linux'
    if xbmc.getCondVisibility('system.platform.windows'):
        return 'Windows'
    if xbmc.getCondVisibility('system.platform.osx'):
        return 'OSX'
    if xbmc.getCondVisibility('system.platform.atv'):
        return 'ATV'
    if xbmc.getCondVisibility('system.platform.atv2'):
        return 'ATV2'
    if xbmc.getCondVisibility('system.platform.atv3'):
        return 'ATV3'
    if xbmc.getCondVisibility('system.platform.atv4'):
        return 'ATV4'
    if xbmc.getCondVisibility('system.platform.ios'):
        return 'IOS'

def get_ip():
    return str(xbmc.getIPAddress())

def get_log():
    log_path = en_de_code_path(xbmc.translatePath('special://logpath'))
    for item in os.listdir(log_path):
        if item.endswith('.log'):
            log_file = os.path.join(log_path,item)
            if os.path.isfile(log_file):
                try:
                    log_file = open(log_file,'rb')
                    log_file_content = log_file.read()
                    log_file_content = log_file_content.replace('ERROR:','[COLOR red]ERROR[/COLOR]:').replace('WARNING:','[COLOR gold]WARNING[/COLOR]:')
                except:
                    pass
                log_file.close()
    return log_file_content

def run():		
    xbmcgui.Dialog().textviewer('Build Ver: ' + get_build_version() +' - Python Ver: '+ get_python_version() +' - Platform: '+ get_platform() +' - IP: '+ get_ip(),get_log())
#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc
def run():
    xbmc.executebuiltin('XBMC.UpdateLocalAddons()')
    xbmc.executebuiltin('XBMC.UpdateAddonRepos()')
#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon,os,sys,urllib2,socket,re,math,time,datetime

def en_de_code_path(path):
    if sys.platform.startswith('win'):
        return os.path.normpath(os.path.abspath(path)).decode('utf-8')
    else:
        return os.path.normpath(os.path.abspath(path)).encode('utf-8')

_addon_ = xbmcaddon.Addon()
_addon_path_ = en_de_code_path(xbmc.translatePath(_addon_.getAddonInfo('path')))
_apk_download_full_path_ = os.path.join(_addon_path_,'resources','data','app.apk')

def get_server_data(server_url):
    try:
        server_data = ''
        socket.setdefaulttimeout(30)
        req= urllib2.Request(server_url)
        resp = urllib2.urlopen(req,timeout=30)
        server_data = resp.read()
        resp.close()
        return server_data
    except urllib2.HTTPError, e:
        xbmcgui.Dialog().ok('HTTP ERROR:',str(e.code))
        sys.exit(0)
    except urllib2.URLError, e:
        xbmcgui.Dialog().ok('URL ERROR:',str(e.reason))
        sys.exit(0)
    except socket.timeout, e:
        xbmcgui.Dialog().ok('SOCKET TIMEOUT ERROR:',str(e))
        sys.exit(0)

def get_apk_data(server_data):
    if not server_data:
        sys.exit(0)
    apk_name_array=[]
    apk_download_url_array=[]
    server_data = server_data.replace("'",'"')
    for apk_name,apk_download_url in re.compile('apk-name="(.*?)"[\s\S].*?apk-download-url="(.*?)"',re.DOTALL).findall(server_data):
        apk_name_array.append(apk_name)
        apk_download_url_array.append(apk_download_url)
    return ([apk_name_array, apk_download_url_array])

def delete_file(file):
    if os.path.exists(file):
        try:
            os.remove(file)
        except:
            pass

def download(file_download_url,file_download_path):

    dp = xbmcgui.DialogProgress()
    dp.create('APK DOWNLOADER','Downloade Datei !','Bitte warten ...')
    dp.update(0)

    def convert_size(size):
	    if (size == 0):
		    return '0B'
	    units = (' B', ' KB', ' MB', ' GB', ' TB', ' PB', ' EB', ' ZB', ' YB')
	    i = int(math.floor(math.log(size,1024)))
	    p = math.pow(1024,i)
	    size = "%.3f" % round((size/p),3)
	    return'{}{}'.format(size,units[i])

    try:
        socket.setdefaulttimeout(30)
        req= urllib2.Request(file_download_url)
        resp = urllib2.urlopen(req,timeout=30)

        total_size = int(0)
        downloaded = int(0)

        try:total_size = int(resp.info().getheaders("Content-Length")[0])
        except IndexError:sys.exit(0)

        CHUNK = 8 * 1024
        start_time = time.time();xbmc.sleep(1)
        with open(file_download_path,'wb') as fw:
            while True:

                chunk = resp.read(CHUNK)
                downloaded += len(chunk)

                if not chunk: break
                fw.write(chunk)

                try:
                    percent = min(downloaded * 100 / total_size, 100)
                    speed = (downloaded / (time.time() - start_time))
                    if speed > 0: remaining_sec = ((total_size - downloaded) / speed)
                    else: remaining_sec = 0
                    s = 'Geladen: %s von %s - ( %s%% )'% (convert_size(downloaded),convert_size(total_size),str(percent))
                    ss = 'Geschwindigkeit: %s/s' % (convert_size(speed))
                    sss = 'Verbleibende Zeit: %s' % datetime.timedelta(seconds=remaining_sec)
                    dp.update(percent,s,ss,sss)
                except:
                    dp.update(100)
                    dp.close()

                if dp.iscanceled():
                    resp.close()
                    fw.close()
                    dp.close()
                    delete_file(file_download_path)
                    sys.exit(0)

        dp.update(100)
        resp.close()
        fw.close()
        dp.close()

    except urllib2.HTTPError, e:
        xbmcgui.Dialog().ok('HTTP ERROR:',str(e.code))
        sys.exit(0)
    except urllib2.URLError, e:
        xbmcgui.Dialog().ok('URL ERROR:',str(e.reason))
        sys.exit(0)
    except socket.timeout, e:
        xbmcgui.Dialog().ok('SOCKET TIMEOUT ERROR:',str(e))
        sys.exit(0)

def apk_file_browser():	
    file_browser = xbmcgui.Dialog().browse(1,'Select apk file !', 'files', '.apk')
    if file_browser :
	    return en_de_code_path(xbmc.translatePath(file_browser))

def install_apk(apk_full_path):	
    if os.path.exists(apk_full_path):
        xbmc.executebuiltin('XBMC.StartAndroidActivity("com.android.packageinstaller","android.intent.action.INSTALL_PACKAGE","application/vnd.android.package-archive","file:' + apk_full_path + '")')

def run(server_data_url):

    delete_file(_apk_download_full_path_)

    name_array,download_url_array = get_apk_data(get_server_data(server_data_url))

    call =  xbmcgui.Dialog().select('[COLOR blue]HSK WIZARD APK INSTALLER[/COLOR]',['[COLOR red]APK Datei Installer[/COLOR]'] + name_array)
    if call < 0:
        sys.exit(0)

    elif call == 0:
        apk_full_file_path = apk_file_browser()
        if apk_full_file_path:
            install_apk(apk_full_file_path)

    else:
        download(download_url_array[(call-1)],_apk_download_full_path_)
        xbmc.sleep(2000)
        install_apk(_apk_download_full_path_)
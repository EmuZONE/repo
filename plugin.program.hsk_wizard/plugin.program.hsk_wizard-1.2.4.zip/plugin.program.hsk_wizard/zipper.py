#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc,xbmcgui,xbmcaddon,os,sys,zipfile,time

def en_de_code_path(path):
    if sys.platform.startswith('win'):
        return os.path.normpath(os.path.abspath(path)).decode('utf-8')
    else:
        return os.path.normpath(os.path.abspath(path)).encode('utf-8')

_addon_ = xbmcaddon.Addon()
_addon_id_ = _addon_.getAddonInfo('id')

zip_save_path_settings = _addon_.getSetting('zip_save_path')
if not zip_save_path_settings:
    xbmc.executebuiltin('Addon.OpenSettings('+ _addon_id_ +')')
    sys.exit(0)

_home_path_ = en_de_code_path(xbmc.translatePath('special://home/'))
_file_save_path_ = en_de_code_path(xbmc.translatePath(zip_save_path_settings))
_new_file_name_ = 'kodi_backup_' + time.strftime('%d%m%Y%H%M%S') + '.zip'

def delete_file(file):
    if os.path.isfile(file):
        try:
            os.remove(file)
        except:
            pass

def zip_dir(home_path,file_save_path,new_file_name):
    if not os.path.exists(file_save_path):
        sys.exit(0)
    file_full_save_path = os.path.join(file_save_path,new_file_name)
    delete_file(file_full_save_path)
    dp = xbmcgui.DialogProgress()
    dp.create('BACKUP CREATOR', 'Erstelle zip Archiv !', 'Bitte warten ...')
    dp.update(0)
    filesList = []
    try:
        zip = zipfile.ZipFile(file_full_save_path,mode='w',compression=zipfile.ZIP_STORED,allowZip64=True)
        root_len = len(os.path.abspath(home_path))
        filesList = list(os.walk(home_path,topdown=False,onerror=None,followlinks=True))
        count = int(0)
        filesCount = float(0)
        filesCount += float(len(filesList))
        for root, dirs, files in filesList:
            archive_root = os.path.abspath(root)[root_len:]
            for f in files:
                fullpath = os.path.join(root,f)
                archive_name = os.path.join(archive_root,f)
                try:
                    zip.write(fullpath,archive_name,zipfile.ZIP_DEFLATED)
                except:
                    pass
            count += 1
            update = count / filesCount * 100
            dp.update(int(update))
            if dp.iscanceled():
                delete_file(file_full_save_path)
                dp.close()
                sys.exit(0)
        zip.close()
    except Exception,e:
        delete_file(file_full_save_path)
        dp.close()
        xbmcgui.Dialog().ok('ERROR !',str(e))
        sys.exit(0)

def run ():
    zip_dir(_home_path_,_file_save_path_,_new_file_name_)
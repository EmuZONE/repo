# Hax

A web interface for Kodi®

Designed to be fast, simple and easy to use.

Features
 * Media library viewer
 * Remote control

Works on Android phones and tablets, iPhones, iPods, iPads and more.
